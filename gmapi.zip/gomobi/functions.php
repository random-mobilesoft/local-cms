<?php
///////////////////////////////////////////////////////////
//
// functions.php - various functions
//
// Copyright (C) 2004 by Rohan Wood
//
//
///////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////
//
// Dump all of the submitted form parameters, used only in development
//
///////////////////////////////////////////////////////////

function dump_params()
{
    print "<b>Parameter Dump</b><br><br><pre>";
    reset($_REQUEST);
    while (list($key, $value) = each($_REQUEST)) {
	print "\n$key = \"$value\"<br>";
    }
    print "</pre>";
}


///////////////////////////////////////////////////////////
//
// Get a http variable, or noting if it does not exist
//
///////////////////////////////////////////////////////////

function get_param($name, $type="")
{
    
	if (isset($_REQUEST[$name])){
		if($type=="d"){
			if(is_numeric($_REQUEST[$name]))return $_REQUEST[$name];
		}
                elseif($type=="s") return mysql_real_escape_string ($_REQUEST[$name]);
		else return addslashes($_REQUEST[$name]);
    }
	return "";
}

///////////////////////////////////////////////////////////
//
// Start a table  
//
///////////////////////////////////////////////////////////

function start_table($class = "default", $attrib="")
{
    print "<table class=\"$class\"".(($attrib)?" $attrib":"").">\n";
}

///////////////////////////////////////////////////////////
//
// Setcolumns  
//
///////////////////////////////////////////////////////////

function define_cols()
{
	$colarg=func_get_args();
    print "\n";
	foreach($colarg as $val){
		print " <col width=\"$val\">";
	}
}


///////////////////////////////////////////////////////////
//
// End  a table
//
///////////////////////////////////////////////////////////

function end_table()
{
    print "</table>\n";
}

///////////////////////////////////////////////////////////
//
// Start a table row
//
///////////////////////////////////////////////////////////

function start_row($params="")
{
    print "\n<tr $params>\n";
}

///////////////////////////////////////////////////////////
//
// End a table row
//
///////////////////////////////////////////////////////////

function end_row()
{
    print "</tr>\n";
}


///////////////////////////////////////////////////////////
//
// Output a column containing a heading. By default it spans
// 2 columns.
//
///////////////////////////////////////////////////////////

function print_heading($heading, $span = 2, $args="")
{
	if(!preg_match("/[[:space:]]/", $heading))$heading = ($heading);
    
    print "<td class=\"heading\" colspan=\"$span\">$heading";
	if(!empty($args["addhead"]))print $args["addhead"];
	print "</td>";
}

///////////////////////////////////////////////////////////
//
// Output a data column aand its label. The data column can
// optionall span multiple columns.
//
///////////////////////////////////////////////////////////

function print_data($label, $data, $other="")
{
    if ($label) {
        $label = $label;
        print "<td class=\"lbl\">$label</td><td class=\"data\"";
    }
    else {
	print "<td $other";
    }
    print ">$data</td>\n";
}

///////////////////////////////////////////////////////////
//
// Output a data column aand its label. The data column can
// optionall span multiple columns.
//
///////////////////////////////////////////////////////////

function print_yell_data($label, $data, $span = 0)
{
    if ($label) {
        $label = ($label);
        print "<td class=\"yellbox\">$label</td><td class=\"data\"";
    }
    else {
	print "<td class=\"data\"";
    }
    if ($span) {
	print " colspan=\"$span\"";
    }
    print ">$data</td>\n";
}

///////////////////////////////////////////////////////////
//
// Output a table row containing a data column and its
// label. The data column can optionally span multiple
// columns.
//
///////////////////////////////////////////////////////////

function print_row($label, $data, $span = 0)
{
    start_row();
    print_data($label, $data, $span);
    end_row();
}

///////////////////////////////////////////////////////////
//
// Output a table row containing a data column and its
// label. Yellow highlighted for subcolumns
//
///////////////////////////////////////////////////////////

function print_yell_row($label, $data, $span = 0, $d2 = "")
{
    start_row();
	if(eregi("^\d$", $span)){
		print_yell_data($label, $data, $span);
	}
	else{
		print_yell_data($label, $data);
		print_yell_data($span, $d2);
	}
	end_row();
}

///////////////////////////////////////////////////////////
//
// Output a table row containing 2 sets of data columns and
// their labels (ie. 4 columns in total).
//
///////////////////////////////////////////////////////////

function print_row_4($label, $data, $label2, $data2)
{
    start_row();
    print_data($label, $data);
    print_data($label2, $data2);
    end_row();
}

///////////////////////////////////////////////////////////
//
// Outputs a table row containing a heading which by
// default spans 2 columns.
//
///////////////////////////////////////////////////////////

function print_heading_row($heading, $span = 2, $args="")
{
    start_row();
    print_heading($heading, $span, $args);
    end_row();
}

///////////////////////////////////////////////////////////
//
// Output a row as a divider. By default it spans
// 2 columns. (not the subdivision)
//
///////////////////////////////////////////////////////////

function print_subsection_row($heading, $span = 2)
{
    $heading = ($heading);
	start_row();
    print "<td class=\"divider\" colspan=\"$span\">$heading</td>";
	end_row();
}

///////////////////////////////////////////////////////////
//
// Returns the HTML to bold a string.
//
///////////////////////////////////////////////////////////

function bold($string)
{
    return "<b>" . $string . "</b>";
}

///////////////////////////////////////////////////////////
//
// start_section
//
// Output the start of collapsable section
//
///////////////////////////////////////////////////////////

$SECTION_NUMBER = 0;	// this is a global

function start_section($title)
{
    global $SECTION_NUMBER;

    $SECTION_NUMBER++;

    $section_id   = $SECTION_NUMBER;
    $status_id    = "section_status_" . $SECTION_NUMBER;
    $button_id    = "section_button_" . $SECTION_NUMBER;

    if(isset($_REQUEST[$status_id])) {
	$section_status = $_REQUEST[$status_id];
    }
    else {
	$section_status = 0;
    }

    if ($section_status) {	// open
	$section_display = "";
	$button_value = "-";
    }
    else {	// closed
	$section_display = "none";
	$button_value = "+";
    }

    // Create a hidden field to hold the current status
    print "<input id=\"$status_id\" type=\"hidden\" name=\"$status_id\" value=\"$section_status\">\n";
    // Create the open/close button
    print "<table width=\"100%\"><tr><td class=\"section\">\n";
    print "<input id=\"$button_id\" type=\"button\" value=\"$button_value\" class=\"butt\" onclick=\"handleClick('$SECTION_NUMBER');\">\n";
    print ($title) . "</td</tr></table>\n";
    print "<span id=\"$section_id\" style=\"display: $section_display\">\n";
}

///////////////////////////////////////////////////////////
//
// Output the end of a collapsable section
//
///////////////////////////////////////////////////////////

function end_section()
{
    print "</span>\n";
}

///////////////////////////////////////////////////////////
//
// Output the start
//
///////////////////////////////////////////////////////////

function start_span($id, $see="", $class="")
{
    print "\n<span id=\"$id\"";
	if($see)print " style=\"display: none\"";
	if($class)print " class=\"$class\"";
	print ">";
}

///////////////////////////////////////////////////////////
//
// start_sub_section
//
// Output the start of collapsable sub section
//
///////////////////////////////////////////////////////////

$SUB_SECTION_NUMBER = 1000;	// this is a global

function start_sub_section($title)
{
    global $SUB_SECTION_NUMBER;

    $SUB_SECTION_NUMBER++;

    $section_id   = $SUB_SECTION_NUMBER;
    $status_id    = "section_status_" . $SUB_SECTION_NUMBER;
    $button_id    = "section_button_" . $SUB_SECTION_NUMBER;

    if(isset($_REQUEST[$status_id])) {
	$section_status = $_REQUEST[$status_id];
    }
    else {
	$section_status = 0;
    }

    if ($section_status) {	// open
	$section_display = "";
	$button_value = "-";
    }
    else {	// closed
	$section_display = "none";
	$button_value = "+";
    }

    // Create a hidden field to hold the current status
    print "<input id=\"$status_id\" type=\"hidden\" name=\"$status_id\" value=\"$section_status\">\n";
    // Create the open/close button
    print "<table width=\"100%\"><tr><td class=\"subsection\">\n";
    print "<input id=\"$button_id\" type=\"button\" value=\"$button_value\" class=\"butt\" onclick=\"handleClick('$SUB_SECTION_NUMBER');\">\n";
    print ($title) . "</td></tr></table>\n";
    print "<span id=\"$section_id\" style=\"display: $section_display\">\n";
}

///////////////////////////////////////////////////////////
//
// Output the start of an modifiable database record
//
// NOTES:
// 1) All the fields associated with with record must have
//    names starting with $prefix followed by an underscore
//    (_).
//
///////////////////////////////////////////////////////////

function start_record($prefix)
{
    print "<span id=\"__record_$prefix\" style=\"display: \">\n";
    print hidden("__record_status_{$prefix}", "1");
}

///////////////////////////////////////////////////////////
//
// Output the end of a modifiable database record
//
// If nodel option is set, the record cannot be deleted.
//
///////////////////////////////////////////////////////////

function end_record()
{
    print "</span>\n";
}

function delete_button($prefix, $value = "Delete")
{
    global $mode;
    if ($mode != "browse") {
        return jsbutton($value, "deleteRecord('$prefix');");
    }
}

///////////////////////////////////////////////////////////
//
// Output the start of an insertable database record
//
///////////////////////////////////////////////////////////

function start_new_record($prefix, $first = 0, $value = "Add")
{
    // work out the next record prefix

    $i = strrpos($prefix, "_") + 1;
    $string = substr($prefix, 0, $i);
    $num = substr($prefix, $i);
    $num++;
    $next_prefix = $string . $num;

    if ($first) {
        print "<span id=\"__record_add_$prefix\" style=\"display: \">\n";
    }
    else {
        print "<span id=\"__record_add_$prefix\" style=\"display: none\">\n";
    }

    $value = ($value);
    print "\n<input type=\"button\" value=\"$value\" width=\"100\" class=\"buttstr\" onClick=\"addRecord('$prefix', '$next_prefix');\">";
   // print jsbutton($value, "addRecord('$prefix', '$next_prefix');");
    print "</span>\n";

    print "<span id=\"__record_$prefix\" style=\"display: none\">\n";
    print hidden("__record_status_{$prefix}", "0");
} 

function delete_new_button($prefix, $value = "Delete")
{
    return jsbutton($value, "deleteNewRecord('$prefix');");
}

///////////////////////////////////////////////////////////
//
// Output the end of an insertable database record
//
///////////////////////////////////////////////////////////

function end_new_record()
{
    print "</span>\n";
}

///////////////////////////////////////////////////////////
//
// show_block
//
// Display a modules block
//
///////////////////////////////////////////////////////////

function show_block($block_id)
{
    $func = "show_block_" . $block_id;
    if (function_exists($func))
	$func();
}

///////////////////////////////////////////////////////////
//
// fix_quotes
//
// Escape single quotes (') for use in MySql queries.
//
///////////////////////////////////////////////////////////

function fix_quotes($string) {
    return(str_replace("'", "''", stripslashes($string)));
}

///////////////////////////////////////////////////////////
//
// Lookup a value in a reference/code table
//
///////////////////////////////////////////////////////////

function lookup($query)
{
    $result = mysql_query($query);
    if (! $result)
	sql_error($query);
    if (mysql_num_rows($result) != 1)
	return("");
    list($value) = mysql_fetch_row($result);
    return($value);
}

///////////////////////////////////////////////////////////
//
// Return the HTML for a hidden field
//
///////////////////////////////////////////////////////////

function hidden($name, $value) {
    return("\n<input type=\"hidden\" name=\"$name\" value=\"$value\" id=\"$name\">");
}

///////////////////////////////////////////////////////////
//
// Return the HTML for a modifiable text field
//
///////////////////////////////////////////////////////////

function text_field($name, $value="", $size=50) {

	

    $my_value = str_replace("\\", "", $value);
	

	$ret = "\n<input type=\"text\" name=\"$name\" value=\"";
	$ret .= $my_value;
	$ret .= "\" id=\"$name\" size=\"$size\">";
    return($ret);
}
///////////////////////////////////////////////////////////
//
// Return the HTML for a year field
//
///////////////////////////////////////////////////////////

function year_field($name, $value="") {
    global $mode;

    switch($mode) {
    case 'browse':
    case 'delete':
	$ret = $value;
	break;
    default:
	$ret = "\n<input type=\"text\" name=\"$name\" value=\"";
	$ret .= $value;
	$ret .= "\" size=\"5\" maxlength=\"4\">";
	break;
    } // end case
    return($ret);
}

///////////////////////////////////////////////////////////
//
// Return the HTML for a modifiable text field (URL)
//
///////////////////////////////////////////////////////////

function url_field($name, $value="", $size=50, $change=0) {
    global $mode;

    $value = str_replace("\\", "", $value);

    switch($mode) {
    case 'browse':
    case 'delete':
	if(!$change){
		$ret=preg_replace("/(http:\/\/)?([[:alnum:]_-]+\.[[:alnum:]_\.-]*[[:alnum:]_-]+)/i", "<a href=\"http://\$2\">\$1\$2</a>", $value);
	}
	else{
		$ret = "\n<input type=\"text\" name=\"$name\" id=\"$name\" readonly value=\"";
		$ret .= $value;
		$ret .= "\" size=\"$size\">";
		}
	break;
    default:
	$ret = "\n<input type=\"text\" name=\"$name\" id=\"$name\" value=\"";
	$ret .= $value;
	$ret .= "\" size=\"$size\">";
	break;
    } // end case
    return($ret);
}

///////////////////////////////////////////////////////////
//
// Return the HTML for a modifiable text field (Email)
//
///////////////////////////////////////////////////////////

function email_field($name, $value="", $size=50, $change=0) {
    global $mode;

    $value = str_replace("\\", "", $value);

    switch($mode) {
    case 'browse':
    case 'delete':
	// Change any email address to clickable links
	$word = '[\\w\\-]+';
	$address = "/$word(\\.$word)*@$word(\\.$word)+/";

	$email = preg_replace($address, '<a href="mailto:\\0">\\0</a>', $value);

	if($change==0)
		$ret = "$email";
	else{
		$ret = "$email<input type=\"text\" name=\"$name\" value=\"";
		$ret .= $value;
		$ret .= "\" size=\"$size\" class=\"permbox\" readonly></a>";}
	break;
    default:
	$ret = "\n<input type=\"text\" name=\"$name\" value=\"";
	$ret .= htmlentities($value);
	$ret .= "\" size=\"$size\">";
	break;
    } // end case
    return($ret);
}
function email_view($value) {
    global $mode;

    $value = str_replace("\\", "", $value);

	// Change any email address to clickable links
	$word = '[\\w\\-]+';
	$address = "/$word(\\.$word)*@$word(\\.$word)+/";

	$email = preg_replace($address, '<a href="mailto:\\0">\\0</a>', $value);

		$ret = "$email";
    return($ret);
}

///////////////////////////////////////////////////////////
//
// Return the HTML for a modifiable text field (Date)
//
///////////////////////////////////////////////////////////

function date_field($name, $value="", $size=20, $change=0) {
    global $mode;
	
	if(!empty($value))
		$value = date("j-n-Y", strtotime($value));

    $value = str_replace("\\", "", $value);
	
    switch($mode) {
    case 'browse':
    case 'delete':
	$ret = $value;
	break;
    default:
	$ret = "\n<input type=\"text\" name=\"$name\" ";
	if($change==1)
		$ret.="readonly class=\"permbox\" ";
	$ret .=" value=\"";
	$ret .= htmlentities($value);
	$ret .= "\" size=\"$size\">";
	break;
    } // end case
    return($ret);
}
///////////////////////////////////////////////////////////
//
// Return the HTML for a modifiable text 
//
///////////////////////////////////////////////////////////

function text_area($name, $value="", $cols=80, $rows=4, $change=0) {
    global $mode;
	global $var;

    $my_value = str_replace("\\", "", $value);
	if($var["mobile"])return nl2br($my_value);

    switch($mode) {
    case 'browse':
    case 'delete':
	if($change==0)
		$ret = nl2br($my_value);
	else{
		$ret = "\n<textarea name=\"$name\" cols=\"$cols\" class=\"permbox\" rows=\"$rows\" readonly>";
		$ret .= $my_value;
		$ret .= "</textarea>";}
	break;
    default:
	$ret = "\n<textarea name=\"$name\" cols=\"$cols\" rows=\"$rows\">";
	$ret .= $my_value;
	$ret .= "</textarea>";
    }
    return($ret);
}
///////////////////////////////////////////////////////////
//
// Return the HTML for a readonly text area
//
///////////////////////////////////////////////////////////

function readonly_text_area($name, $value="", $cols=60, $rows=6) {
    global $mode;

    $my_value = str_replace("\\", "", $value);

    switch($mode) {
    case 'browse':
    case 'delete':
	$ret = nl2br($my_value);
	break;
    default:
	$ret = "\n<textarea name=\"$name\" cols=\"$cols\" rows=\"$rows\" class=\"permbox\" readonly>";
	$ret .= $my_value;
	$ret .= "</textarea>";
    }
    return($ret);
}

///////////////////////////////////////////////////////////
//
// Return the HTML for a checkbox (implemented as a drop
// down list of yes & no).  Includes a hidden field so that
// empty checkbox fields are also returned
//
///////////////////////////////////////////////////////////

function checkbox($name, $value="", $change=0, $dynam=0) {
    global $mode;

    switch($mode) {
    case 'browse':
    case 'delete':
	if($change==0){
	if ($value) {
	    $ret = "[X]";
		}
	else {
	    $ret = "";
	}
	}
	else{
		$ret = "\n<input name=\"$name\" type=\"checkbox\" class=\"permbox\" disabled value=\"1\"";
		if ($value) {
	 	   $ret .= " checked";
		}
		$ret .= ">";
	}
	break;
    default:
	$ret = "\n<input name=\"checkbox_{$name}\" type=\"checkbox\" value=\"1\"";
	if ($value) {
	    $ret .= " checked";
	}
	$ret .= " onClick=\"checkBox('$name');\">";
	$ret .= "\n<input name=\"$name\" type=\"hidden\" value=\"$value\">";
    } // end case
	if(!$dynam){
		$ret = "<input name=\"$name\" type=\"checkbox\" ";
		if ($value) {
		   $ret .= " checked";
		}
		$ret .= ">";
	}
    return($ret);
}
function checkboxp($name, $value="") {
    global $mode;

 	$ret = "\n<input name=\"{$name}\" type=\"checkbox\" value=\"1\"";
	if ($value) {
	    $ret .= " checked";
	}
	$ret .= ">";
    return($ret);
}

///////////////////////////////////////////////////////////
//
// Load the contents of a query into a associative array
//
///////////////////////////////////////////////////////////

function load_array($query)
{
    $values = array();
	
	$db=new DBQ($query);

    $numfields = $db->numfields();;

    while ($row = $db->row()) {
	if ($numfields == 1) {
	    $values[$row[0]] = $row[0];
	}
	else {
	    $values[$row[0]] = $row[1];
	}
    }

    return $values;
}

///////////////////////////////////////////////////////////
//
// Return the HTML for a drop down list.
//
///////////////////////////////////////////////////////////

function select($name, $query, $default="", $prompt = "Select a value", $size=0)
{

	global $var;
	
    $ret = "";

    if (is_array($query)) {
		$values = $query;
    }
    else {
        $values = load_array($query);
    }
 

 	$ret = "\n<select name=\"$name\"";
	if ($size) {
	    $ret .= " size=$size";
	}
	$ret .= ">";

	if ($prompt) {
            $ret .= "\n<option value=\"\">".($prompt)."</option>";
	}
	while (list ($key, $value) = each($values)) { 
		$ret .= "\n<option value=\"$key\"";
		if ($default != "" && $key == $default) {
			$ret .= " selected";
		}
		$ret .= ">$value</option>";
	} // end while
	$ret .= "</select>";
    return($ret);
}

///////////////////////////////////////////////////////////
//
// Return the HTML for a picklist of months
//
///////////////////////////////////////////////////////////

function month_field($name, $default="", $prompt = "Selamon") {
    global $mode;

    $month[1] = "January";
    $month[] = "February";
    $month[] = "March";
    $month[] = "April";
    $month[] = "May";
    $month[] = "June";
    $month[] = "July";
    $month[] = "August";
    $month[] = "September";
    $month[] = "October";
    $month[] = "November";
    $month[] = "December";

    if ($mode == "browse" || $mode == "delete") {
	$ret = "";
	if (isset($month[$default])) {
	    $ret = $month[$default];
	}
    }
    else {
        $ret = "\n<select name=\"$name\">";
        $ret .= "\n<option value=\"\">" . ($prompt) . "</option>";
        for ($i = 1; $i < 13; $i++) {
	    $ret .= "\n<option value=\"$i\"";
	    if ($i == $default) {
	        $ret .= " selected";
	    }
	    $ret .= ">" . $month[$i] . "</option>";
        }
        $ret .= "</select>";
    }
    return $ret;
}
    
///////////////////////////////////////////////////////////
//
// Return the HTML for a picklist populated from a
// database table
//
///////////////////////////////////////////////////////////

function picklist($name, $query, $default="", $submit=0, $nil=0, $change=0)
{
    global $mode;

    if (is_array($query)) {
        $values = $query;
    }
    else {
        $values = load_array($query);
    }

    if ($submit) {
	if ($submit==1) $submit="submit();";
	$ret = "\n<select name=\"$name\" onChange=\"$submit\">";
    }
    else {
 	if ($change == 0 || $mode != "browse")		
	    $ret = "\n<select name=\"$name\">";
	else
	    $ret = "\n<select name=\"$name\" class=\"permbox\" disabled>";
    }

    if (!$nil)
       $ret .= "\n<option value=\"\">" . "Select a Value" . "</option>";

    while (list($key, $value) = each($values)) {
	$ret .= "\n<option value=\"$key\"";
	if ($default == $key) {
	    $ret .= " selected";
	}
	$ret .= ">$value";
    } // end while

    $ret .= "</select>";
    return($ret);
}

///////////////////////////////////////////////////////////
//
// Return the HTML for a submit button
//
///////////////////////////////////////////////////////////

function submit($name, $value, $javascript = "") {
    $value = ($value);
    $ret = "\n<input type=\"submit\" name=\"$name\" class=\"butt\" value=\"$value\"";
    if ($javascript) {
	$ret .= " onclick=\"$javascript\"";
    }
    $ret .= ">";
    return($ret);
}

///////////////////////////////////////////////////////////
//
// Return the HTML for a button which calls some javascript
//
///////////////////////////////////////////////////////////

function jsbutton($value, $script, $a=array()) {
	$id="";
	if(!empty($a["id"]))$id=$a["id"];
    $value = ($value);
	$ins="";
	if($id)$ins.=" id=\"$id\"";
    return("<input type=\"button\" value=\"$value\"$ins class=\"butt\" onClick=\"$script\">");
}

///////////////////////////////////////////////////////////
//
// Return the HTML for a country picklist
//
///////////////////////////////////////////////////////////

function pickcountry($name, $default) {
    global $language;

    $query = "select sigle, country" . $language . " from countries order by country" . $language;

    $values = mysql_query($query);
    if (! $values) {
	sql_error($query);
    }

    $ret = "\n<select name=\"$name\" onChange=\"submit();\">";
    
    $ret .= "\n<option value=\"\">" . ("Select a Country") . "</option>";
    while ($row = mysql_fetch_row($values)) {
	$ret .= "\n<option value=\"$row[0]\"";
	if ($default == $row[0]) {
	    $ret .= " selected";
	}
	$ret .= ">" . $row[1] . "</option>";
    } // end while
    $ret .= "</select>";
    return($ret);
}

///////////////////////////////////////////////////////////
//
// Updates a record in the database using values returned
// from a HTML form.
//
// PARAMETERS:
// record_name	Name of the database table.
// prefix	Any HTML form values starting with this
//		string foloowed by an '_' will be used to
//		populate the table.
// primary_key	Name of the primary key column.
//
///////////////////////////////////////////////////////////

function update_record($record_name, $prefix, $primary_key, $prem="")
{
	global $d;
	
	$prefix .= "_";

    $query = "select ";
    $count = 0;
    reset($_REQUEST);
    while (list($key, $value) = each($_REQUEST)) {
//	if (substr($key, 0, $len) == $prefix) {
	if (preg_match("/^".$prefix."/", $key)) {

	    if($prem){
	    	$test=preg_match("/^[A_Za-z]+_\d+_(.+)$/", $key, $m);
		if($test){
			$column_name=$m[1];
		}
	    }
	    else $column_name = $key;
//	    $column_name = $key;
	    if ($column_name == $primary_key) { // ignore primary key
		if($prem)$pkey=$key;
		else $pkey=$primary_key;
		continue;
	    }
	    if ($count != 0) {
		$query .= ",";
	    }
	    $query  .= $column_name;
	    $count++;
	}
    }

    $query .= " from $record_name where ";
    $query .= "$primary_key = '" . $_REQUEST["{$pkey}"] . "'";

    $result = mysql_query($query);
    if (!$result) {
	sql_error($query);
    }

    $data = mysql_fetch_array($result);

    // Build the update query

    $query = "update $record_name set ";

    $count = 0;
    reset($_REQUEST);
    while (list($key, $value) = each($_REQUEST)) {
	if (preg_match("/^".$prefix."/", $key)) {
	    if($prem){
	    	$test=preg_match("/^[A_Za-z]+_\d+_(.+)$/", $key, $m);
		if($test){
			$column_name=$m[1];
		}
	    }
	    else $column_name = $key;
	    if ($column_name == $primary_key) {
		continue;	// skip if primary key
	    }
	    if(preg_match("/date/i",$column_name)){// date fields are manipulated to fit MySQL which uses YYYY-MM_DD
			$darray=explode("/", $value);
			krsort($darray);
			reset($darray);
			$i=0;
			$value="";
			foreach($darray as $comp){
			if($i) $value.="-";
			$value.=$comp;
			$i++;
			}
			if($value=="") $value=NULL;
		}
	    if (stripslashes($value) == $data[$column_name]) {
		continue;	// skip if data has not changed
	    }
		
		$count++;
	    if ($count > 1) {
		$query .= ",";
	    }

	    if($value==NULL)$query .= "$column_name = NULL";
		else $query .= "$column_name = '".addslashes($value)."'";
		
	}
    }
    $query .= " where $primary_key = '" . $_REQUEST[$pkey] . "'";
   // print $query;

    if ($count > 0) {
		$check=true;

        if (!$d=new DBQ($query))$check=false;
        
		

	//	if($check){

	///		$query="insert into audit(action, tableused, recordid, username)
	//		 values(\"U\", \"$record_name\", \"" . $_REQUEST["{$prefix}{$primary_key}"] . "\", \"".$USERID."\")";

	//		$result=mysql_query($query);
	//	}
    }
}

///////////////////////////////////////////////////////////
//
// Inserts a record into the database using values returned
// from a HTML form.
//
// PARAMETERS:
// record_name	Name of the database table.
// prefix	Any HTML form values starting with this
//		string foloowed by an '_' will be used to
//		populate the table.
//
// An audit insert is also perfomed via odbc to preserve the newly minted id
//
///////////////////////////////////////////////////////////

function insert_record($record_name, $prefix)
{
	global $last_insert_id;
	
    $prefix .= "_";

	$count=0;
    $query = "insert into $record_name (";
    $values = "";
    reset($_REQUEST);
    while (list($key, $value) = each($_REQUEST)) {
	if (preg_match("/^".$prefix."/", $key) and $value != "") {
	    $count++;
	    $column_name = $key;
		if(eregi("date",$column_name)){
			$darray=explode("/", $value);
			krsort($darray);
			reset($darray);
			$i=0;
			$value="";
			foreach($darray as $comp){
			if($i) $value.="-";
			$value.=$comp;
			$i++;
			}
		}
	    if ($count > 1) {
		$query .= ",";
		$values .= ",";
	    }
		
		$value=addslashes($value);
	    $query .= "$column_name";
	    $values .= "'$value'";
	}
    }
    $query .= ") values ($values)";
    if ($count > 0) {
	
		$check=true;
        $result = mysql_query($query);
        if (!$result) {
	    	sql_error($query);
        }
		//if($check){// audit insert
			$last_insert_id=mysql_insert_id();
			
		//	if($prefix=="ncdir_"){
		//		add_last_user("D", $last_insert_id);
		//	}

		//	$query = "insert into audit(action, tableused, recordid, username)
	//	 values(\"I\", \"$record_name\", \"$last_insert_id\", \"".$USERID."\")";

	//		$result = mysql_query($query);
	//		if (!$result) {
	//			sql_error($query);
	//		}

	//	}
    }
}

///////////////////////////////////////////////////////////
//
// Deletes one or more records
//
// PARAMETERS:
// record_name	The name of the database record.
// where	The where clause (including the word 'where')
//
///////////////////////////////////////////////////////////

function delete_record($record_name, $where)
{
	global $USERID;
	
	$query = "delete from $record_name " . $where;
    $test = mysql_query($query);
	$gone=true;
    if (!$test) {
		if(preg_match("/foreign key/i", mysql_error()))warn("Cannot delete record with dependent records");
		else sql_error($query);
		$gone=false;
	}
	return $gone;
	
}

///////////////////////////////////////////////////////////
//
// Processes a group of records defined using the
// start_record, end_record or start_new_record,
// end_new_record functions. Will update, insert and delete
// the corresponding database records as required.
//
// PARAMETERS:
// record_name	Name of the database record.
// prefix	The prefix used for the form fields and as
//		an option to start_record, etc.
// key		The name of the primary key column.
// 
///////////////////////////////////////////////////////////

function process_record_group($record_name, $prefix, $key, $prem="")
{
    $i = 0;

    while (isset($_REQUEST["__record_status_{$prefix}_{$i}"])) {
        $status = $_REQUEST["__record_status_{$prefix}_{$i}"]; 

        switch ($status) {
        case 0:         // not used
            break;
        case 1:         // existing record
            if(!$prem)update_record($record_name, "{$prefix}_{$i}", $key);
            else update_record($record_name, "{$prefix}_{$i}", $key, 1);
            break;
        case 2:         // delete existing record
	    $where = "where $key = '" . $_REQUEST["{$prefix}_{$i}_${key}"] .
		     "'";
            delete_record($record_name, $where, $_REQUEST["{$prefix}_{$i}_${key}"]);
            break;
        case 3:         // insert next record
            insert_record($record_name, "{$prefix}_{$i}");
            break;
        }
        $i++;
    }
}

///////////////////////////////////////////////////////////
//
// Close a pop-up window
//
// NOTE: Must be called prior to any output.
//
///////////////////////////////////////////////////////////

function close_window()
{
?>
<html>
<body onload='window.close();'>
</body>
</html>
<?php
    exit();
}

///////////////////////////////////////////////////////////
//
// Reloads main data
//
// PARAMETERS:
// prefic	the field identifier type
// 
//
///////////////////////////////////////////////////////////

function reload_data($prefix)
{
    $prefix .= "_";
    $len = strlen($prefix);
	$arr=array();
    reset($_REQUEST);
    while (list($key, $value) = each($_REQUEST)) {
	if (substr($key, 0, $len) == $prefix) {
		$rkey=substr($key, $len);
		$arr[$rkey]=$value;
	}
    }
	return $arr;
}

///////////////////////////////////////////////////////////
//
// Reloads grouped data
//
// PARAMETERS:
// prefic	the field identifier type
// i the record identifier
//
///////////////////////////////////////////////////////////

function reload_groupdata($prefix, $i)
{
	$arr=array();


    $prefix .= "_{$i}_";
    $len = strlen($prefix);
    reset($_REQUEST);
    while (list($key, $value) = each($_REQUEST)) {
	if (substr($key, 0, $len) == $prefix) {
		$rkey=substr($key, $len);
		$arr[$rkey]=$value;
	}
    }
	return $arr;
	
}

///////////////////////////////////////////////////////////
//
//  Close all sections
// 
///////////////////////////////////////////////////////////

function close_all_sections()
{
    $i = 0;
    reset($_REQUEST);
    while (list($key, $value) = each($_REQUEST)) {
	if (substr($key, 0, 15) == "section_status_") {
		$_REQUEST[$key]=0;
	}
    }
}
///////////////////////////////////////////////////////////
//
// Print a blank row with a default span of 2
//
///////////////////////////////////////////////////////////


function print_blank_row($span=2)
{
	echo "\n<tr><td height=\"20\" colspan=\"$span\">&nbsp;</td></tr>\n";
}

///////////////////////////////////////////////////////////
//
// Print warning
//
///////////////////////////////////////////////////////////

function print_warn(){

if($warn=warn());
	print "<p class=\"warn\">$warn</p>";
}
///////////////////////////////////////////////////////////
//
// XML data addition, will add a new tag and entry to an xml construction
//
///////////////////////////////////////////////////////////

function pr_xml($fld, $cdata="" ,$group="data",  $lang="", $tag=""){
	global $data;
	global $row;
	global $xml_output;
	
	$cstart="";
	$cend="";
	$el="";
	
	if($cdata){
		$cstart="<![CDATA[";
		$cend="]]>";
	}
	
	if($lang){
		$lt="";
		$thing=substr($fld, -1);
		if(strtoupper($thing)=="E") $lt="en";
		elseif(strtoupper($thing)=="F") $lt="fr";
		elseif(strtoupper($thing)=="S") $lt="es";
		if($lt)$el=" xml:lang=\"$lt\"";
	}

	if($group==1){ 
		$xml_output .= "<$tag$el>".$cstart.$fld.$cend."</$tag>";
		return;
	}

	$input=${$group}["$fld"];
	$input=str_replace("&", "&amp;", $input);

	if($input){
		if($el) $fld=substr($fld, 0, -1);
		$xml_output .= "<$fld$el>".$cstart.$input.$cend."</$fld>";
	}
}
///////////////////////////////////////////////////////////
//
//open an xml tag
//
///////////////////////////////////////////////////////////

function o_xml($fld, $eltype="", $index=""){
	global $xml_output;
	global $data;
	
	//if the xml_output is not initiated, commence xml_output
	if(!isset($xml_output)) $xml_output = "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>";
	
	//enable the unique identification of a tag
	if($eltype)$xml_output .= "<$fld $eltype=\"".$data[$index]."\">";
	else $xml_output .= "<$fld>";

}

///////////////////////////////////////////////////////////
//
//close an xml tag
//
///////////////////////////////////////////////////////////

function c_xml($fld){
	global $xml_output;
	
	$xml_output .= "</$fld>";
}
///////////////////////////////////////////////////////////
//
//delete an xml file
//
///////////////////////////////////////////////////////////

function delete_xml($filename){
$filename.=".xml";
if(is_file("xml/".$filename))unlink("xml/".$filename);
}

///////////////////////////////////////////////////////////
//
// Language swap - will put either put data in from another language
//   when language of choice not available or will diaplay a message
//   to say data is there, but not in selected language
//
///////////////////////////////////////////////////////////

function lswap($key, $array, $msg=0){
	global $lc;
	$ret=$array[$key.$lc];
	if(!$ret){
		if($lc=="E"){
			if($array[$key."F"]){
				if(!$msg)$ret=$array[$key."F"];
				else $ret="Field not available in this language";
			}
			elseif($array[$key."S"]){
				if(!$msg)$ret=$array[$key."S"];
				else $ret="Field not available in this language";
			}
		}
		elseif($lc=="F"){
			if($array[$key."E"]){
				if(!$msg)$ret=$array[$key."E"];
				else $ret="Donn�es non disponibles en cette langue";
			}
			elseif($array[$key."S"]){
				if(!$msg)$ret=$array[$key."S"];
				else $ret="Donn�es non disponibles en cette langue";
			}
		}
		elseif($lc=="S"){
			if($array[$key."E"]){
				if(!$msg)$ret=$array[$key."E"];
				else $ret="Datos no disponibles en esta lengua";
			}
			elseif($array[$key."F"]){
				if(!$msg)$ret=$array[$key."F"];
				else $ret="Datos no disponibles en esta lengua";
			}
		}
	}
	return $ret;
}

///////////////////////////////////////////////////////////
//
// Check the email server - will ping the smtp server to check it is connected
//
///////////////////////////////////////////////////////////

function checkmail(){
	  ob_start();
      system("ping -n 1 ".ini_get('SMTP'));
      $pingtest = ob_get_contents();
	  ob_end_clean();
    $pingres = preg_match("/Lost = 0/i", $pingtest);
	return $pingres;
}

///////////////////////////////////////////////////////////
//
// print_para - eneter a new paragraph
// 
///////////////////////////////////////////////////////////

function print_para($data, $class="default"){
	print "\n<p class=\"$class\">".$data."\n</p>";
}

///////////////////////////////////////////////////////////
//
// Help Status - output DHTML help
// 
///////////////////////////////////////////////////////////

function text_help($data, $caption="", $params=""){

	if(PRINT_STATE)return;
	$ins=text_phrase($data);// pull out the relevant help from another function (see below)
	if(!$ins)$ins=("Help is not available at this time")." - ".$data;//output generis message if help not found
	if($caption)$ins2=" - ".addslashes(($caption));//create the caption for the title bar
	else $ins2="";
	if($params){// if additional parameters are to be passed to overlib.js, then process this
		if(!is_array($params))$ins3=", $params";//if attribute is a string, add it
		else {// if attribute is an array, turn it into a long comma seperated strring
			$ins3="";
			foreach($params as $value)$ins3.=", $value";
		}
	}
	else $ins3="";
	//put all the text bits together and pass it back as a string that can be printed or otherwise processed
	if(file_exists("images/help.gif"))$img="images/help.gif";
	else $img="../../images/help.gif";
	$ret= "\n<img src=\"$img\" alt=\"".("help").$ins2."\" onclick=\"return overlib('$ins', STICKY, CAPTION, '".
	("help").$ins2."'".$ins3.");\">";
	return $ret;
}
///////////////////////////////////////////////////////////
//
// Help Status - pull phrases from the Help table
// 
///////////////////////////////////////////////////////////


function text_phrase($data){
	global $lc;
	
	//get both the nominated language phrse and an english version
	$query="select help$lc, helpE from nc_help where code like '$data' limit 1";
	$result=mysql_query($query);
	if(!$result)sql_error($query);
	$data=mysql_fetch_assoc($result);
	if($data["help".$lc])$ins=nl2br($data["help".$lc]);// if stated language help is found, use that
	else $ins=nl2br($data["helpE"]);// otherwise go with English
	$ins=str_replace("\n", "", $ins);// do a bit of tidying up the string
	$ins=str_replace("\r", "", $ins);
	$ins=addslashes($ins);
	return $ins;// return the string
}

///////////////////////////////////////////////////////////
//
// MINI PAGE START
// Get mail details and send
// 
///////////////////////////////////////////////////////////
function start_page(){
	?>
<html>
<head>
<title>NCP</title>
<style>
<?=include("styles.css")?>
</style>
<script language="JavaScript" src="common/index.js"></script>
<script language="JavaScript" src="common/overlib/overlib.js"><!-- overLIB (c) Erik Bosrup --></script>
</head>
<body onLoad="focus()">
<div id="overDiv" style="position:absolute; visibility:hidden; z-index:1000;"></div>
<form name="mainform" method="post" action="index.php">
	<?php
}


//end the html output
function end_page(){
	?>
</form>
</body>
</html>
	<?php
	die();//stop
}

function inc_jsscript($location){
	print "\n<script type=\"text/javascript\" src=\"$location\"></script>";
}
// function to display history of changes

function popup($title, $body){

	$body=nl2br($body);
	//$body=preg_replace(array("/\r/", "/\n/", "/'/", '/"/'), array("", "", "\'", '\"'), $body);
	//$body=preg_replace(array("/\r/", "/\n/", "/'/"), array("", "", "\'"), $body);
	$body=preg_replace(array("/\r/", "/\n/"), array("", ""), $body);
	$body=htmlspecialchars($body);
	//$body=str_replace("\n", "", $body);
	//$body=str_replace("'", "\'", $body);
	
	$ret="\n<a onClick=\"overlib('".$body."', STICKY, CAPTION, '".htmlentities($title, ENT_QUOTES)."', RIGHT);\">";
	return $ret;
}

function warn($msg=""){
	static $fullmsg;
	if($msg){
		if($fullmsg)$fullmsg.="\n<br />";
		$fullmsg.=$msg;
		return;
	}
	elseif($fullmsg)return "\n<span class=\"warn\">".$fullmsg."<br /></span>";
	else return;
}

function date_check($data, $future=0){
	$test=preg_match("/^([0-3]?[0-9])[[:punct:]]([0-1]?[0-9])[[:punct:]]((20)?0[5-9])$/", $data, $match);
	if($test){
		
	}
}


function set_prev_entries($prefix){
	reset($_REQUEST);
	$ret=array();
	foreach($_REQUEST as $key=>$value){
		if(preg_match("/^".$prefix."/", $key))$ret[$key]=$value;
	}
	return $ret;
}

function image_thumb($image, $a=array()){

	$type="tn";
	$id="";
	$alt="";
	$apfx="";
	if(!empty($a["type"]))$type=$a["type"];
	if(!empty($a["id"]))$id=$a["id"];
	if(!empty($a["alt"]))$alt=$a["alt"];
	if(!empty($a["apfx"]))$apfx=$a["apfx"]."/";
	
	if(strtolower($type)!="tn"){
		if(strtolower($type)=="md")$type="md";
		else $type="bg";
		$image=preg_replace("/_tn_([\d]+\.)/", "_".$type."_"."\$1", $image);
	}
	if(file_exists(GM_BASE."/images/".$apfx.$image)){
		$ins=GM_BASE."/images/".$apfx.$image;
	}
	else $ins=GM_BASE."/images/tn_noimage.jpg";
	if(!$image)$ins=GM_BASE."/images/tn_noimage.jpg";
	elseif(file_exists("images/".$apfx.$image))$ins="images/".$apfx.$image;
	elseif(file_exists("../images/".$apfx.$image))$ins="../images/".$apfx.$image;
	else $ins=GM_BASE."/images/tn_noimage.jpg";
	
	$ret="<img src=\"$ins\"";
	if($id) $ret.=" id=\"$id\"";
	if($alt)$ret.=" alt=\"".htmlspecialchars($alt)."\"";
	$ret .=" border=\"0\"/>";
	return $ret;
}

function htmlspecialchars_uni($text)
{
        $text = preg_replace('/&(?!#[0-9]+;)/si', '&amp;', $text); 
        return str_replace(array('<', '>', '"'), array('&lt;', '&gt;', '&quot;'), $text);
}

function unhtmlspecialchars($text, $doUniCode = false)
{
	if ($doUniCode)
	{
		$text = preg_replace('/&#([0-9]+);/esiU', "convert_int_to_utf8('\\1')", $text);
	}

	return str_replace(array('&lt;', '&gt;', '&quot;', '&amp;'), array('<', '>', '"', '&'), $text);
}

function ordinal_suffix($value, $sup = 0){
    if(!is_numeric($value))return $value;
    if(substr($value,-2,2)==11||substr($value,-2,2)==12||substr($value,-2,2)==13)$suffix="th";
    else if (substr($value, -1, 1) == 1)$suffix = "st";
    else if (substr($value, -1, 1) == 2)$suffix = "nd";
    else if (substr($value, -1, 1) == 3)$suffix = "rd";
    else $suffix = "th";
    if($sup)$suffix = "<sup>" . $suffix . "</sup>";
    return $value . $suffix;
}

function radio_field($name, $value, $other="") {

	

    $my_value = str_replace("\\", "", $value);
	

	$ret = "\n<input type=\"radio\" name=\"$name\" value=\"";
	$ret .= $my_value;
	$ret .= "\" id=\"$value\" $other>";
    return($ret);
}
?>
