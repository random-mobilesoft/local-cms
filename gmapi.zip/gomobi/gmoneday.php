<?php
$error="";
$verror="";
$mobdomain="";
ob_start();
include_once("config.php");
include_once("library/gomobi.class.php");
include_once("library/gomobiFunctions.php");
include_once("db.php");
//include_once("dbM.php");
//include_once("functions.php");

function get_param($name, $type="")
{
    
	if (isset($_REQUEST[$name])){
		if($type=="d"){
			if(is_numeric($_REQUEST[$name]))return $_REQUEST[$name];
		}
                elseif($type=="s") return mysql_real_escape_string ($_REQUEST[$name]);
		else return addslashes($_REQUEST[$name]);
    }
	return "";
}

$url=get_param("u");
$email=get_param("e");
$phone=get_param("m");
$encode=get_param("n");
$bname=get_param("b");
$address=get_param("a");
$fbook=get_param("f");
$twitter=get_param("t");
$custom=get_param("c");
if(MTA_LOGIT){
    logItems("email is ".$email);
    logItems("phone is ".$phone);
    logItems("encode is ".$encode);
    logItems("url is ".$url);
    reset($_REQUEST);
    foreach($_REQUEST as $k=>$v)logItems("$k is $v");
}
if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
    $verror="email is invalid";
}

if(strtolower(substr($url, 0, 4))!="http")$url="http://".$url;
//if(!preg_match('|^http(s)?://[a-z0-9-]+(.[a-z0-9-]+)*(:[0-9]+)?(/.*)?$|i', $url)){
elseif(!filter_var($url, FILTER_VALIDATE_URL)){
    $verror="url is invalid";
}


if(substr($url,0,8)=="https://")$url=substr($url,8);
elseif(substr($url,0,7)=="http://")$url=substr($url,7);
$gm=new gomobi();
if(1==2 && LM_SANDBOX){
    $mobdomain="test.local.mobi";
    $j=10;
}
else $j=strlen($verror);
for($i=$j;$i<1;$i++){
    $tins="";
    if(LM_SANDBOX){
        $gm->isSandbox();
        $tins="&lm_sandbox=1";
    }
    else $gm->isProd();
    $gm->logSend(true);
    $array=array("sub_reseller_id"=>"localmobi",
         "source"=>$url, 
         //"mobile"=>  str_replace(".", "", $url).".local.mobi",
         "promcode"=>"free_trial:1day");

    if($custom){
        if($address)$array["address"]=$address;
        if($phone)$array["phone"]=$phone;
    }


     if(!$gm->loadSubscriptionRequest($array)){
         //print "suberror: ".$gm->getError();
         $error=$gm->getError();
         break;
    }
     elseif(!$gm->send()){
       // print "suberror: ".$gm->getError();
         $error=$gm->getError();
         break;
    }
     else{
         $pass=md5(strval($gm->rXML->data->mobile_domain)." is just a step away from glory");
         $d=new DBQ();
         $d->nq("insert into t1day(t1_url, t1_subscription, t1_mobile_url, t1_password, t1_email, t1_phone) values('".$url.
                    "','".strval($gm->rXML->data->subscription_reference)."','".strval($gm->rXML->data->mobile_domain)."', '$pass', '".
                    mysql_real_escape_string($email)."', '".mysql_real_escape_string($phone)."')");
         $mobdomain=strval($gm->rXML->data->mobile_domain);
      //   $mobdomain="mytinyadcom21.sb.local.mobi";
         if($custom){
             if(MTA_LOGIT){
                logItems("Doing custom for ".$mobdomain);
            }

             $carr=array();
             $parr=array();
             if($twitter){
                 if(strrpos("/", $twitter)!==FALSE){
                     $carr["Twitter"]=array("value"=>substr($twitter, (strrpos("/", $twitter)+1)));
                     $parr["twitter"]=substr($twitter, (strrpos("/", $twitter)+1));
                 }
                 else{
                     $carr["Twitter"]=array("value"=>$twitter);
                     $parr["twitter"]=$twitter;
                 }
             }
             if($fbook){
                 if(strrpos("/", $fbook)!==FALSE)$carr["Facebook"]=substr($fbook, (strrpos("/", $fbook)+1));
                 else $carr["Facebook"]=$fbook;
             }
             if($email)$carr["Leave A Message"]=array("value"=>$email);
             if($phone)$carr["Call Us"]=array("value"=>$phone);
             if($bname)$parr["title"]=$bname;
             if(MTA_LOGIT){
                 foreach($carr["Twitter"] as $kx=>$vx)logItems("$kx and $vx for ".$mobdomain);
                
            }
             
             $gm->setActionUpdateBatch();
             $gm->setMapping($mobdomain);
             $gm->updateBatch($carr, $parr);
             if(!$gm->send()){
                // print "suberror: ".$gm->getError();
                  $error=$gm->getError();

             }
            
         }
     }


     function randomPassword() {
        $alphabet = "abcdefghijklmnopqrstuwxyzABCDEFGHIJKLMNOPQRSTUWXYZ0123456789";
        $pass = array(); //remember to declare $pass as an array
        $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
        for ($i = 0; $i < 8; $i++) {
            $n = rand(0, $alphaLength);
            $pass[] = $alphabet[$n];
        }
        return implode($pass); //turn the array into a string
    }
}
$obfail=  ob_get_clean();
if($obfail){
    $out="Unknown Error";
    $pos=0;
}
elseif($error){
    $out=$error;
    $pos=0;
}
elseif($verror){
    $out=$verror;
    $pos=2;
    sleep(1);
}
else{
    $out=$mobdomain;
    $pos=1;
}
if(MTA_LOGIT){
    logItems("pos is $pos and out is ".$out);
}
if($pos==1){
    include_once("library/class.phpmailer.php");
    $e=new PHPMailer();
    $e->AddAddress($email);
    $e->Subject="Test email for mobile domain: ".$url;
    $e->Body="The domain ".$out." is yours to claim.";
    $e->Send();
}


if($encode=="xml"){
    header("Content-Type: text/xml; charset=iso-8859-1");
    header("Content-Disposition: inline;filename=result.xml");
    header("Expires: Fri, 30 Oct 1998 14:19:41 GMT");
    header("Cache-Control: no-cache, must-revalidate");

    print "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?><onedayer><result>$pos</result><detail>$out</detail></onedayer>";
}
elseif($encode=="plain"){
    print "result: ".$pos."\ndetail: ".$out;
}
else{
    header("Content-Type: application/json;");
    header("Content-Disposition: inline;filename=result.json");
    header("Expires: Fri, 30 Oct 1998 14:19:41 GMT");
    header("Cache-Control: no-cache, must-revalidate");
    print json_encode(array("result"=>$pos,"detail"=>$out));
    
}

    function logItems($item){
        $ins="\n".date("r")."\n     ";
        $filename="logs/oneday_".  date("Ymd").".log";
        file_put_contents($filename, $ins.$item, FILE_APPEND);
    }

?>
