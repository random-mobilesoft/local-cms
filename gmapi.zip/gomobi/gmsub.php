<?php
$fail="http://www.local.mobi/web/create-mobile-site/failed/";
$success="http://www.local.mobi/web/demo-24-hours/";

include_once("config.php");
include_once("library/gomobi.class.php");
include_once("library/gomobiFunctions.php");
include_once("db.php");
//include_once("dbM.php");
//include_once("functions.php");

function get_param($name, $type="")
{
    
	if (isset($_REQUEST[$name])){
		if($type=="d"){
			if(is_numeric($_REQUEST[$name]))return $_REQUEST[$name];
		}
                elseif($type=="s") return mysql_real_escape_string ($_REQUEST[$name]);
		else return addslashes($_REQUEST[$name]);
    }
	return "";
}

$url=get_param("u");
if(!preg_match('|^http(s)?://[a-z0-9-]+(.[a-z0-9-]+)*(:[0-9]+)?(/.*)?$|i', $url)){
    header("Location: ".$fail);
    exit(1);
}
$email=get_param("e");
$phone=get_param("m");

if(substr($url,0,8)=="https://")$url=substr($url,8);
elseif(substr($url,0,7)=="http://")$url=substr($url,7);

$gm=new gomobi();

$tins="";
if(LM_SANDBOX){
    $gm->isSandbox();
    $tins="&lm_sandbox=1";
}
else $gm->isProd();
$gm->logSend(true);
$array=array("sub_reseller_id"=>"localmobi",
     "source"=>$url, 
     //"mobile"=>  str_replace(".", "", $url).".local.mobi",
     "promcode"=>"free_trial:1day");




 if(!$gm->loadSubscriptionRequest($array)){
     //print "suberror: ".$gm->getError();
      header("Location: ".$fail);
     exit(1);
}
 elseif(!$gm->send()){
   // print "suberror: ".$gm->getError();
      header("Location: ".$fail);
     exit(1);
}
 else{
     $pass=md5(strval($gm->rXML->data->mobile_domain)." is just a step away from glory");
     $d=new DBQ();
     $d->nq("insert into t1day(t1_url, t1_subscription, t1_mobile_url, t1_password, t1_email, t1_phone) values('".$url.
                "','".strval($gm->rXML->data->subscription_reference)."','".strval($gm->rXML->data->mobile_domain)."', '$pass', '".
                mysql_real_escape_string($email)."', '".mysql_real_escape_string($phone)."')");
     header("Location: ".$success."?lm_url=".urlencode(strval($gm->rXML->data->mobile_domain))."&lm_cs=".$pass.$tins);
 }
 
 
 function randomPassword() {
    $alphabet = "abcdefghijklmnopqrstuwxyzABCDEFGHIJKLMNOPQRSTUWXYZ0123456789";
    $pass = array(); //remember to declare $pass as an array
    $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
    for ($i = 0; $i < 8; $i++) {
        $n = rand(0, $alphaLength);
        $pass[] = $alphabet[$n];
    }
    return implode($pass); //turn the array into a string
}

?>
