<?php
define("LM_SANDBOX", 1); //1 is sandbox, 0 is production

define("MSDB_HOST", "mta-db.cnpfwlf1436d.us-west-2.rds.amazonaws.com");
define("MSDB_USER", "mta");
define("MSDB_PASS", "MyTinyAd");
define("MSDB_NAME", "localmobi");
define( 'DB_NAME', 'localm1' );
define( 'DB_USER', 'localm_LM' );
define( 'DB_PASSWORD', 'D5cpz?pXZft4' );
define( 'DB_HOST', 'mtamy.cjhvacxhbz7f.ap-southeast-2.rds.amazonaws.com' );
define("MTA_RS_SECRET", "gohawks");
define("MTA_RS_API", "p559ffW(.4gg1");
define("MTA_API_SERVER", "http://localapi.mobi/api/v1/");
define("MTA_HOME", "http://www.local.mobi/web/");
define("MTA_LOGIT", true);


if(isset($_SERVER["SERVER_NAME "]) && $_SERVER["SERVER_NAME "]=="localhost"){
    $dbuser="root";
    $dbpass="";
}
?>
