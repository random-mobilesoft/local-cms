<?php
session_start();
if(isset($_GET["logoff"])){
    unset($SESSION["logged"]);
    session_destroy();
    header("Location: about_change.php");
    exit();
}
$users=array("glovebox"=>"M3gaDrive");

if(empty($_SESSION["logged"])){
        if(!isset($_SESSION["logcount"]))$_SESSION["logcount"]=0;
        $_SESSION["logcount"]++;
        if($_SESSION["logcount"]>10){
          print "<p style=\"color: red;\">Too many bad logins</p>";
            exit();
        }
        
        if(!empty($_REQUEST["login"]) && isset($users[strtolower($_REQUEST["login"])]) && $users[strtolower($_REQUEST["login"])]==$_REQUEST["password"]){
            $_SESSION["logged"]=1;
            $go=1;
        }
        elseif(!empty($_REQUEST["login"]) )print "<p style=\"color: red;\">Wrong login</p>";
        if(empty($SESSION["logged"]) && empty($go)){
 ?>
<!DOCTYPE html>
<html>
    <head>
        <title></title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    </head>
    <body>
<form name="loginme" method="post">
Username  <input type="text" name="login" size="20">
Password <input type="password" name="password" size="20"> <input type="submit" name="submit" vale="submit">
</form>
   </body>
</html>
<?php
        exit();
        }
        
        
}
include_once("functions.php");
include_once("config.php");
include_once("library/gomobi.class.php");
include_once("library/gomobiFunctions.php");
include_once("library/class.phpmailer.php");
include_once("db.php");
//include_once("common/dbm.php");
//include_once("common/auth.php");
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

$regmap=  get_param("dommap");
$rmlen=(0-strlen($regmap));
$email=get_param("email");
$gacode=get_param("adsense");
if(get_param("turnon"))$turnon=1;
else $turnon=0;
$mappings=array();
set_time_limit(7200);
if(isset($_FILES["bulkup"])){
 //   foreach($_FILES["bulkup"] as $k=>$v)print "$k and $v \n<br />";
    $bad=0;
  if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
    warn("$email is not a valid email address");
    $bad=1;
  } 
  if(substr($regmap,0,1)==".")$regmapt="www.".$regmap;
  else $regmapt=$regmap;
  if(!filter_var("http://".$regmapt, FILTER_VALIDATE_URL)){
    warn("$regmap is not a valid url");
    $bad=1;
  }  
  if(!is_numeric($gacode)){
    warn("$gacode is not a number");
    $bad=1;
  }  
  if(strlen($regmap)<13){
    warn("$regmap isn't long enough");
    $bad=1;
  }  
  if ($_FILES["bulkup"]["error"] > 0)
  {
     warn("<Error: " . $_FILES["bulkup"]["error"]);
  }
elseif(!$bad){
        $i=0;
        
        if (($handle = fopen($_FILES["bulkup"]["tmp_name"], "r")) !== FALSE) {
        while (($data = fgetcsv($handle, 4000, ",", "\"")) !== FALSE) {
            if(!$i){
                if($data[4]!="Status"){
                    print "\"status\" must be in cell 5";
                    print_r($data);
                    exit();
                }
                $i++;
            }
            //foreach($data as $v){
                if(isset($data[5]) && $data[4]=="A" && substr($data[5], $rmlen)==$regmap){
                    $mappings[]=$data[5];
                }
            //}
           
        }
        fclose($handle);
       
    }
    if(!count($mappings)){
        warn("No valid sites found");
        
    }
    else{
        $d=new DBQ("truncate table adcheck");
        $q="insert into adcheck(ac_mapping) values('".implode("'),('",$mappings)."')";
        $d->nq($q);

        //include_once("dbM.php");
        //include_once("functions.php");

        
        reset($mappings);
        $body="Doing $regmap for $gacode, turnon = $turnon";
        foreach($mappings as $map){
        //for($i=0;$i<1;$i++){
            $body.="\n$map ";
            $gm=new gomobi();
            $gm->setMapping($map);
            if(!LM_SANDBOX)$gm->isProd();
            else $gm->isSandbox();
            $gm->logSend(true);
            $debug=0;
            $appid=0;
          
            

            $gm->setActionGetApps();
            if(!$gm->send()){
                if($debug)print "suberror: ".$gm->getError();
                $error=$gm->getError();
                $body.=" ".$error;
            }
            else{
                $tinst=count((array)$gm->rXML->data->app_instances->app_instance);
                for($j=0;$j<$tinst;$j++){
                    if(isset($gm->rXML->data->app_instances->app_instance[$j]->config->ad_id) && strval($gm->rXML->data->app_instances->app_instance[$j]->config->ad_id)==$gacode){
                        $appid=strval($gm->rXML->data->app_instances->app_instance[$j]->id);
                        if(strval($gm->rXML->data->app_instances->app_instance[$j]->config->ad_position)=="above-header")$apos=1;
                        else $apos=0;
                        if(strval($gm->rXML->data->app_instances->app_instance[$j]->config->ad_home_page)==1 && strval($gm->rXML->data->app_instances->app_instance[$j]->config->ad_sub_pages)==1)$alive=1;
                        else $alive=0;
                        break;
                    }
                }

                 if($appid && (!$apos || $alive!=$turnon)){
                    $xml=new SimpleXMLElement("<?xml version='1.0'?><request><app_instance/></request>");
                    $xml->app_instance->label="Ads";
                    $xml->app_instance->position="-1";
                    $xml->app_instance->icon="5032";
                    $xml->app_instance->share="0";
                    $xml->app_instance->config[0]->ad_service="google";
                    $xml->app_instance->config[0]->ad_id=$gacode;
                    $xml->app_instance->config[0]->ad_position="above-header";
                    $xml->app_instance->config[0]->ad_home_page=$turnon;
                    $xml->app_instance->config[0]->ad_sub_pages=$turnon;
                    $xml->app_instance->config[0]->ad_slot="";
                    $xml->app_instance->config[0]->ad_publisher="";
                    $gm->rXML="";

                    $gm->request=$xml->asXML();        

                    $gm->setActionUpdateApp($appid);
                    if(!$gm->send()){
                       if($debug)print "suberror: ".$gm->getError();
                       $error=$gm->getError();
                       $body.=" ".$error;
                    }
                    else $body.=" good";

                }
                elseif(!$appid){
                    $xml=new SimpleXMLElement("<?xml version='1.0'?><request><apps/></request>");
                    $xml->apps->app[0]->id="16";
                    $xml->apps->app[0]->label="Ads";
                    $xml->apps->app[0]->position="-1";
                    $xml->apps->app[0]->icon="5032";
                    $xml->apps->app[0]->share="0";
                    $xml->apps->app[0]->config[0]->ad_service="google";
                    $xml->apps->app[0]->config[0]->ad_id=$gacode;
                    $xml->apps->app[0]->config[0]->ad_position="above-header";
                    $xml->apps->app[0]->config[0]->ad_home_page=$turnon;
                    $xml->apps->app[0]->config[0]->ad_sub_pages=$turnon;
                    $xml->apps->app[0]->config[0]->ad_slot="";
                    $xml->apps->app[0]->config[0]->ad_publisher="";
                    $gm->rXML="";

                    $gm->request=$xml->asXML();        
                    $gm->setActionUpdateApps();
                    if(!$gm->send()){
                       if($debug)print "suberror: ".$gm->getError();
                       $error=$gm->getError();
                       $body.=" ".$error;
                    }
                    else $body.=" good";

                }
                else $body.=" no action";
               // else print_r($gm->rXML);
               // print_r($gm->rXML);


            }








        }
        $e=new PHPMailer();
        $e->AddAddress($email);
        $e->IsHTML(false);
        $e->From="info@local.mobi";
        $e->FromName="local.mobi";
        $e->Subject="Update run for locl.mobi";
        $e->Body=$body;

        $e->Send();

    }
    
  }
  
}

?>
<html>
    <head>
        <title>Ads adjust</title>
        <style>
            .warn{
                color:  red;
            }
        </style>
    </head>    
    <body>
        <?php print warn()?>
        <h1>Ads Adjust</h1>    
        <?php
            if(empty($welcome)){
                //print $authtxt;
                //exit();
            }
?>
        
        <p><b>Select a file to upload</b>
          <br />The file you upload must be in CSV format (export as csv from excel). The CSV expected should be the default layout from gomobi.
          <br />Once submitted, the page will eventually timeout, but it is working and you should NOT resubmit for a couple of hours. Check some known mobile sites for progress.
          <br />Specify the email address where you want the final report sent.
          <br />If you want a single reseller only, apply that filter when you download the CSV from gomobi
        <br /><br />
        <form method="post" enctype="multipart/form-data">


<table>
            <tr><td>file to upload: </td><td><input type="file" name="bulkup" id="bulkup"></td></tr>
            <tr><td>domain mapping to match: </td><td><input type="text" name="dommap" id="dommap" value="<?php print $regmap;?>"></td></tr>
            <tr><td>adsense code: </td><td><input type="text" name="adsense" id="adsense" value="<?php print $gacode;?>"></td></tr>
            <tr><td>alert email: </td><td><input type="text" name="email" id="email" value="<?php print $email;?>"></td></tr>
            <tr><td>adsense status: </td><td>Turn on: <input type="radio" name="turnon" value="1" checked> Turn off: <input type="radio" name="turnon" value="0"></td></tr>
            <tr><td>sandbox: </td><td><input type="checkbox" name="s" value="1" checked></td></tr>
            <tr><td colspan="2"><input type="submit" name="submit" value="Submit"></td></tr>
        </table>
        </p>
</form>
        
    </body>  
</html>




<?php


 

    function logItems($item){
        $ins="\n".date("r")."\n     ";
        $filename="logs/oneday_".  date("Ymd").".log";
        file_put_contents($filename, $ins.$item, FILE_APPEND);
    }

?>
