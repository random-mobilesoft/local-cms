<?php
$fail="http://www.local.mobi/build-fail/";
$success="http://www.local.mobi/manage-jm-site/";

include_once("config.php");
include_once("library/gomobi.class.php");
include_once("library/gomobiFunctions.php");
include_once("db.php");
//include_once("dbM.php");
//include_once("functions.php");

function get_param($name, $type="")
{
    
	if (isset($_REQUEST[$name])){
		if($type=="d"){
			if(is_numeric($_REQUEST[$name]))return $_REQUEST[$name];
		}
                elseif($type=="s") return mysql_real_escape_string ($_REQUEST[$name]);
		else return addslashes($_REQUEST[$name]);
    }
	return "";
}
$valresllers=array("JMG", "localmobi");
$url=get_param("u");
$email=get_param("e");
$phone=get_param("m");
$encode=get_param("n");
$bname=get_param("b");
$address=get_param("a");
$fbook=get_param("f");
$twitter=get_param("t");
$custom=get_param("c");
$prefsite=get_param("p");
$urltld=get_param("g");
$subreseller=get_param("reseller");
$verror="";
$error="";
$urltld=substr($urltld, 0, (strlen($urltld)-11));
if(!in_array($subreseller, $valresllers))$subreseller="localmobi";
if(MTA_LOGIT){
    logItems("email is ".$email);
    logItems("phone is ".$phone);
    logItems("encode is ".$encode);
    logItems("url is ".$url);
 //   reset($_REQUEST);
 //   foreach($_REQUEST as $k=>$v)logItems("$k is $v");
}
if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
    $verror="email is invalid";
}

if(strtolower(substr($url, 0, 4))!="http")$url="http://".$url;
//if(!preg_match('|^http(s)?://[a-z0-9-]+(.[a-z0-9-]+)*(:[0-9]+)?(/.*)?$|i', $url)){
elseif($url && !filter_var($url, FILTER_VALIDATE_URL)){
    $verror="desktop website is invalid";
}
if(!preg_match("/^[a-zA_Z]+$/", $urltld)){
    $verror="tld is invalid";
}
//if(!preg_match("/^[a-zA_Z]+(\.[a-zA_Z]+)*$/", $prefsite)){
 //   $verror="preferred site is invalid";
//}

if(substr($url,0,8)=="https://")$url=substr($url,8);
elseif(substr($url,0,7)=="http://")$url=substr($url,7);
if(substr($prefsite,0,8)=="https://")$prefsite=substr($prefsite,8);
elseif(substr($prefsite,0,7)=="http://")$prefsite=substr($prefsite,7);
if(LM_SANDBOX)$prefsite=  str_replace(" ", "", $prefsite).".".$urltld.".sb.local.mobi";
else $prefsite=  str_replace(" ", "", $prefsite).".".$urltld.".local.mobi";
$gm=new gomobi();
if(1==2 && LM_SANDBOX){
    $mobdomain="test.local.mobi";
    $j=10;
}
else $j=strlen($verror);
for($i=$j;$i<1;$i++){
    $tins="";
    if(LM_SANDBOX){
        $gm->isSandbox();
        $tins="&lm_sandbox=1";
    }
    else $gm->isProd();
    $gm->logSend(true);

    if($custom){
         $array=array("sub_reseller_id"=>$subreseller,
         "mobile"=>$prefsite);
       if($address)$array["address"]=$address;
        if($phone)$array["phone"]=$phone;
        if($url)$array["source"]=$url;
    }
    else{    
        $array=array("sub_reseller_id"=>$subreseller,
         "source"=>$url);
    }

     if(!$gm->loadSubscriptionRequest($array)){
         //print "suberror: ".$gm->getError();
         $error=$gm->getError();
         break;
    }
     elseif(!$gm->send()){
       // print "suberror: ".$gm->getError();
         $error=$gm->getError();
         break;
    }
     else{
         if($custom)$mobdomain=$prefsite;
         else $mobdomain=strval($gm->rXML->data->mobile_domain);
         $pass=md5(strval($mobdomain)." is just a step away from glory");
         $d=new DBQ();
         $d->nq("insert into t1workday(t1_url, t1_subscription, t1_mobile_url, t1_password, t1_email, t1_phone) values('".$url.
                    "','".strval($gm->rXML->data->subscription_reference)."','".strval($mobdomain)."', '$pass', '".
                    mysql_real_escape_string($email)."', '".mysql_real_escape_string($phone)."')");
         
      //   $mobdomain="mytinyadcom21.sb.local.mobi";
         if($custom){
             if(MTA_LOGIT){
                logItems("Doing custom for ".$mobdomain);
            }

             $carr=array();
             $parr=array();
             if($twitter){
                 if(strrpos("/", $twitter)!==FALSE){
                     $carr["Twitter"]=array("value"=>substr($twitter, (strrpos("/", $twitter)+1)));
                     $parr["twitter"]=substr($twitter, (strrpos("/", $twitter)+1));
                 }
                 else{
                     $carr["Twitter"]=array("value"=>$twitter);
                     $parr["twitter"]=$twitter;
                 }
             }
             if($fbook){
                 if(strrpos("/", $fbook)!==FALSE)$carr["Facebook"]=substr($fbook, (strrpos("/", $fbook)+1));
                 else $carr["Facebook"]=$fbook;
             }
             if($email)$carr["Leave A Message"]=array("value"=>$email);
             if($phone)$carr["Call Us"]=array("value"=>$phone);
             if($bname)$parr["title"]=$bname;
             if(MTA_LOGIT){
                 foreach($carr["Twitter"] as $kx=>$vx)logItems("$kx and $vx for ".$mobdomain);
                
            }
             
             $gm->setActionUpdateBatch();
             $gm->setMapping($mobdomain);
             $gm->updateBatch($carr, $parr);
             if(!$gm->send()){
                // print "suberror: ".$gm->getError();
                  $error=$gm->getError();

             }
            
         }
     }



}
$obfail=  ob_get_clean();
if($obfail){
    $out="Unknown Error";
    $pos=0;
      header("Location: ");
     exit(1);
   
}
elseif($error){
    $out=$error;
    $pos=0;
     header("Location: ".$fail."?errormsg=".  urlencode($error));
     exit(1);
}
elseif($verror){
    $out=$verror;
    $pos=2;
    sleep(1);
     header("Location: ".$fail."?errormsg=".  urlencode($verror));
     exit(1);
}
else{
    $out=$mobdomain;
    $pos=1;
}
if(MTA_LOGIT){
    logItems("pos is $pos and out is ".$out);
}
if($pos==1){
    include_once("library/class.phpmailer.php");
    $e=new PHPMailer();
    $e->AddAddress("info@local.mobi");
    $e->IsHTML(false);
    $e->From="info@local.mobi";
    $e->FromName="local.mobi";
    $e->Subject="Local.mobi access and account details for ".$mobdomain;
    $body=  "Can be found at http://www.local.mobi/manage-jm-site/?lm_url=".$out;
    $e->Body=$body;
    
    $e->Send();
    
}
function get_gomobi_link(){
global $wpdb;
$private_keyfile = '/etc/ssl/certs/gomobi.private.key';
// Load private key
$privkey = file_get_contents($private_keyfile);
$pkeyid = openssl_pkey_get_private($privkey);
// Reseller id, .mobi domain, time
//$reseller_id = 65590;                 // MyTinyAd Production Reseller ID
if(!empty($_REQUEST["lm_sandbox"]))$sandbox=1;
else $sandbox=0;

if(isset($_REQUEST["lm_url"]))$mobile_domain_name=$_REQUEST["lm_url"];
else $mobile_domain_name="missing";
if(substr($mobile_domain_name,0,8)=="https://")$mobile_domain_name=substr($mobile_domain_name,8);
elseif(substr($mobile_domain_name,0,7)=="http://")$mobile_domain_name=substr($mobile_domain_name,7);

if(substr($mobile_domain_name, -14)==".sb.local.mobi")$sandbox=1;

if($sandbox)$reseller_id=65573;
else $reseller_id  = 65590;

$d=new DBQ();
$d->nq("select t1_int from t1workday where t1_mobile_url='".mysql_real_escape_string($mobile_domain_name)."' and t1_status=0");
$val="";
if($d->cr()){
    $row=$d->row();
    $val=$row["t1_int"];
}
if(!$val){
    return "expired";
    exit();
}


$time = time();
// A message to sign
$msg = implode('/', array($reseller_id, $mobile_domain_name, $time));
// Sign the message
openssl_sign($msg, $signature, $pkeyid);
openssl_pkey_free($pkeyid);
// Final URL
//$cp_entry_point = 'https://cp.instantmobilizer.com';
//$cp_entry_point = 'https://cp-sandbox.instantmobilizer.com';

if($sandbox)$cp_entry_point = "https://cp-sandbox.instantmobilizer.com";
else $cp_entry_point = "https://cp.instantmobilizer.com";
$lang = 'en';
$url = $cp_entry_point."/".$msg."/".urlencode(base64_encode($signature))."/".$lang;
return $url;
}


header("Location: ".$success."?lm_url=".urlencode($out)."&lm_cs=".$pass.$tins."&lm_link=".  urlencode(get_gomobi_link()));










 
 function randomPassword() {
    $alphabet = "abcdefghijklmnopqrstuwxyzABCDEFGHIJKLMNOPQRSTUWXYZ0123456789";
    $pass = array(); //remember to declare $pass as an array
    $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
    for ($i = 0; $i < 8; $i++) {
        $n = rand(0, $alphaLength);
        $pass[] = $alphabet[$n];
    }
    return implode($pass); //turn the array into a string
}
    function logItems($item){
        $ins="\n".date("r")."\n     ";
        $filename="logs/oneday_".  date("Ymd").".log";
        file_put_contents($filename, $ins.$item, FILE_APPEND);
    }

?>
