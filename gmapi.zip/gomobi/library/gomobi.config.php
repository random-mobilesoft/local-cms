<?php

define("GM_USERNAME", "mytinyad");
define("GM_PASSWORD", "darthvader101");
//define("GM_PASSWORD", "k2mvTvNzm");


define("GM_PRODURL", "https://api.instantmobilizer.com/v1");
define("GM_SANDBOXURL", "https://api-sandbox.instantmobilizer.com/v1");

define("GM_LOG_LOCATION", "./logs");
//define("GM_LOG_LOCATION", "D:/junk/logs");

?>
