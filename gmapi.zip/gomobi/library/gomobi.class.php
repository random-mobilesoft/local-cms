<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of gomobi
 *
 * @author rohan
 */

/**
 * VERSION: 0.4a
 * DATE: 2013-09-09
 * 0.4 added update app function
 */

include_once("gomobi.config.php");

class gomobi {
    //put your code here
    
    var $action = "allProperties";
    var $mapping = "";
    var $appid = 0;
    var $gmprodurl = "something";
    var $token = "";
    var $error;
    var $response;
    var $gmAppItems;
    var $rXML;
    var $request;
    var $logSend=0;
    var $gmref;
    var $adhocReq;
    var $appreq=0;
    var $reqType = "XML";
    var $dest = GM_SANDBOXURL;
    var $ignoredApps;
    var $subscription;
    var $apps=array("Call Us"=>array("id"=>1, "vname"=>"callus_phone", "icon"=>1001),
        "Find Us"=>array("id"=>2),
        "Full Website"=>array("id"=>3),
        "Tell a Friend"=>array("id"=>5, "vname"=>"sms_body_text"),
        "News Feed"=>array("id"=>6),
        "Leave a Message"=>array("id"=>7, "vname"=>"email", "icon"=>1007),
        "Opening Hours"=>array("id"=>8),
        "Booking Request"=>array("id"=>9),
        "Images"=>array("id"=>11),
        "Create Link"=>array("id"=>12),
        "Coupon"=>array("id"=>13),
        "Call Me Back"=>array("id"=>14),
        "Blog"=>array("id"=>15),
        "Monetise"=>array("id"=>16),
        "Google Analytics"=>array("id"=>17),
        "Keep me informed"=>array("id"=>21),
        "Social Media Icons"=>array("id"=>23),
        "Traffic Booster"=>array("id"=>24),
        "Legal"=>array("id"=>25),
        "Twitter"=>array("id"=>26, "vname"=>"social_media_link_login", "icon"=>1026),
        "Facebook"=>array("id"=>29, "vname"=>"social_media_link_login", "icon"=>1029),
        "About"=>array("id"=>32, "vname"=>"link_url", "vother"=>array("is_link"=>1, "page_content"=>""), "aother"=>array("link"=>"")),
        "Products"=>array("id"=>33),
        "Services"=>array("id"=>34),
        "Create Page"=>array("id"=>36),
        "Videos"=>array("id"=>37),
        "Site Translation"=>array("id"=>39),
        "Event Calendar"=>array("id"=>40),
        "Marketing Connect"=>array("id"=>42),
        "Location Base Services"=>array("id"=>43),
        "Forms"=>array("id"=>47),
        "Reviews"=>array("id"=>48));

  
    function isProd(){
        $this->dest = GM_PRODURL;
    }
    function isSandbox(){
        $this->dest = GM_SANDBOXURL;
    }
    function setRequestXML(){
        $this->reqType = "XML";
    }
    function setRequestJSON(){
        $this->reqType = "JSON";
    }
    function setActionAllProperties(){
        $this->action="allProperties";
    }
    function setActionAllApps(){
        $this->action="allApps";
    }
    function setActionSubRequest(){
        $this->action="subRequest";
    }
    function setActionRenewRequest(){
        $this->action="subRenew";
    }
    function setActionGetApps(){
        $this->action="getApps";
    }
    function setActionGetAccount(){
        $this->action="getAccount";
    }
    function setActionChangeContract(){
        $this->action="changeContract";
    }
    function setActionUpdateApps(){
        $this->action="updApps";
        $this->appreq=0;
    }
    function setActionUpdateApp($app){
        $this->action="updApp";
        $this->appid=$app;
    }
    function setActionUpdateBatch(){
        $this->action="updBatch";
        $this->appreq=0;
    }
    function setActionGetToken(){
        $this->action="getToken";
    }
    function setActionAdHocRequest(){
        $this->action="adhoc";
    }
    function setActionUpdateProperties(){
        $this->action="updProp";
    }
    function setMapping($map){
        $this->mapping=$map;
    }
    function setSubscription($subscription){
        $this->subscription=$subscription;
    }
    function setGmRef($ref){
        $this->gmref=$ref;
    }
    function getAuthToken(){
        $this->setActionGetToken();
        
    }
   function logSend($act){
        if($act)$this->logSend=1;
        else $this->logSend=0;
        
    }
    
    function send(){
         
        if($error=$this->validateAction()){
            $this->setError($error);
            return false;
        }
 
        
        $items=$this->getItemsToSend();
        
        if($this->logSend)$this->logItems($items["method"]." ".$items["url"]);
           
        $ch = curl_init($items["url"]);
        curl_setopt ($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC );
        curl_setopt ($ch, CURLOPT_USERPWD, GM_USERNAME.":".GM_PASSWORD);
        curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt ($ch, CURLOPT_TIMEOUT, 90);
        if($this->reqType=="JSON") curl_setopt ($ch, CURLOPT_HTTPHEADER, array("Accept: application/json", "Content-Type: application/json"));
        curl_setopt ($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        if($items["method"]=="POST"){
            if($this->logSend)$this->logItems($this->request);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $this->request);
            curl_setopt($ch, CURLOPT_POST, TRUE);
        }
        if($items["method"]=="PUT"){
            if($this->logSend)$this->logItems($this->request);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
            curl_setopt($ch, CURLOPT_POSTFIELDS, $this->request);

        }
        $response = curl_exec ($ch);
        $errno = curl_errno ($ch);
        if($this->logSend)$this->logItems($response);
        if($errno){
            $err_str = curl_error ($ch);
            $this->error=$errno.": ".$err_str;
            if($this->logSend)$this->logItems($this->error);
            curl_close ($ch);
            return false;
        }
        curl_close ($ch);
        $this->response=$response;
        try{
            if($this->reqType=="XML")$this->rXML=new SimpleXMLElement($this->response);    
            else{
                $jsontest=json_decode($this->response);
                if(isset($jsontest->response->data))$this->rXML=$jsontest->response->data;
            }
        } catch (Exception $e){
            $this->setError("CURL:".$e->getMessage());
            return false;
        }
        if($this->reqType=="XML"){
            if(!isset($this->rXML->status)){
                $this->setError($this->reqType." response returned, but status is missing");
                return false;
            }
            if($this->rXML->status!="ok"){
                if(isset($this->rXML->error)){
                    if(isset($this->rXML->errno))$this->setError(strval($this->rXML->errno)." - ".strval($this->rXML->error));
                    else $this->setError("Error received - ".strval($this->rXML->error));
                }
                else $this->setError($this->reqType." response returned, but error is unknown");
                return false;
            }
        }
        else{
            if(!isset($jsontest->response->status)){
                $this->setError($this->reqType." response returned, but status is missing");
                return false;
            }
            if($jsontest->response->status!="ok"){
                if(isset($jsontest->response->error)){
                    if(isset($jsontest->response->errno))$this->setError(strval($jsontest->response->errno)." - ".strval($jsontest->response->error));
                    else $this->setError("Error received - ".strval($jsontest->response->error));
                }
                else $this->setError($this->reqType." response returned, but error is unknown");
                return false;
            }
           
        }
        
        if($this->action=="allApps"){
            $this->populateGMApps();
        }
        return true;
    }
    
    function getItemsToSend(){
        
        $ret=array();
        if($this->action=="allProperties"){
            $ret["url"]=$this->dest."/mapping/".$this->mapping."/properties";
            $ret["method"]="GET";
        }
        elseif($this->action=="allApps"){
            $ret["url"]=$this->dest."/mapping/".$this->mapping."/apps";
            $ret["method"]="GET";
        }
       elseif($this->action=="getApps"){
            $ret["url"]=$this->dest."/mapping/".$this->mapping."/app_instances";
            $ret["method"]="GET";
        }
       elseif($this->action=="getAccount"){
            $ret["url"]=$this->dest."/mapping/".$this->mapping;
            $ret["method"]="GET";
        }
       elseif($this->action=="transfer"){
            $ret["url"]=$this->dest."/subscription/".$this->gmref."/transfer";
            $ret["method"]="POST";
        }
        elseif($this->action=="subRequest"){
            $ret["url"]=$this->dest."/create_site";
            $ret["method"]="POST";
           // $ret["postbody"]=$this->request;
       }
        elseif($this->action=="subRenew"){
            $ret["url"]=$this->dest."/subscription/".$this->subscription."/renew";
            $ret["method"]="POST";
           // $ret["postbody"]=$this->request;
       }
        elseif($this->action=="changeContract"){
            $ret["url"]=$this->dest."/subscription/".$this->subscription."/contract_type";
            $ret["method"]="PUT";
           // $ret["postbody"]=$this->request;
       }
        elseif($this->action=="updProp"){
            $ret["url"]=$this->dest."/mapping/".$this->mapping."/properties";
            $ret["method"]="PUT";
           // $ret["postbody"]=$this->request;
       }
        elseif($this->action=="updBatch"){
            $ret["url"]=$this->dest."/mapping/".$this->mapping."/configure";
            $ret["method"]="POST";
           // $ret["postbody"]=$this->request;
       }
        elseif($this->action=="updApps"){
            $ret["url"]=$this->dest."/mapping/".$this->mapping."/app_instances";
            $ret["method"]="POST";
           // $ret["postbody"]=$this->request;
       }
       elseif($this->action=="updApp"){
            $ret["url"]=$this->dest."/mapping/".$this->mapping."/app_instances/".$this->appid;
            $ret["method"]="PUT";
       }
        elseif($this->action=="adhoc"){
            $ret["url"]=$this->dest.$this->adhocReq["url"];
            $ret["method"]=$this->adhocReq["method"];
           // $ret["postbody"]=$this->request;
       }
         if(count($ret))return $ret;   
         else return false;
    }
    
    function validateAction(){
        if($this->action=="allApps" || $this->action=="allProperties" || $this->action=="getAccount" || $this->action=="updProp" || $this->action=="updApps" || $this->action=="updApp" || $this->action=="getApps" || $this->action=="updBatch"){
           if(!preg_match("/^[\w,\.-]+$/ ", $this->mapping)){
                    return "Mapping ".$this->mapping." is invalid";
           }
           else return 0;
        }
         elseif($this->action=="transfer"){
           if(!preg_match("/^[\w,\.-]+$/ ", $this->mapping)){
                    return 0;
                    //return "Mapping ".$this->mapping." is invalid";
           }
           else return 0;
        }
        elseif($this->action=="subRequest"){
           if(!preg_match("/xml/ ", $this->request)){
                    return "Request is invalid";
           }
           else return 0;
        }
       elseif($this->action=="subRenew" || $this->action=="changeContract"){
           if(empty($this->subscription)){
                    return "Subscription is invalid";
           }
          if(empty($this->request)){
                    return "Request is empty";
           }
           else return 0;
        }
        elseif($this->action=="adhoc"){
           if(!isset($this->adhocReq["url"])){
                    return "URL is missing";
           }
           elseif(!isset($this->adhocReq["method"])){
                    return "Method is missing";
           }
           else return 0;
        }
        else return "no validation exists";
    }
    function populateGMApps(){
        if(!isset($this->rXML->data->apps))$this->setError ("No valid XML to populate");
        $kids=$this->rXML->data->apps->app->count();
        for($i=0;$i<$kids;$i++){
            $app=$this->rXML->data->apps->app[$i];
           //  print "\n<br />".$app->name." - ".$app->app_instances->app_instance->count();
            $ai=$app->app_instances->app_instance->count();
            print "\n<br />".$this->rXML->data->apps->app[$i]->id."|".$this->rXML->data->apps->app[$i]->name;
            for($ai=0;$ai<$kids;$ai++){
                
            }
        }
       // print_r($this->rXML->data->apps);
        
    }
    function transferSite($newloc){
        if(!$this->gmref){
                $this->setError("no reference set");
                return false;
            }
            if(!preg_match("/^[\w\.]+$/", $newloc)){
                $this->setError("New location $newloc is invalid");
                return false;
            }
            $this->action="transfer";
            $this->request="<?xml version=\"1.0\"?>
<request>
   <sub_reseller_id>$newloc</sub_reseller_id>
</request>";
            if(!$this->send()){
                return false;
            }
            return true;
    }
    function loadSubscriptionRequest($items){
        $this->setActionSubRequest();
        if(!is_array($items)){
            $this->setError("invalide payload - not an array");
            return false;
        }
        //do required items first
   //      if(empty($items["mobile"])){
    //        $this->setError("Required items missing, resellerid or mobiledomain");
    //        return false;
    //    }
        $vads=array("spare_1"=>"/^[\.\w\__\d\s}]{1,255}$/", "spare_2"=>"/^[\.\w\__\d\s}]{1,255}$/", "sub_reseller_id"=>"/^[\.\w\__\d\s}]{1,255}$/",
            "reseller_reference"=>"/^[\.\w\__\d\s}-]{1,255}$/", "source"=>"/^([A-Z0-9][A-Z0-9_-]*(?:.[A-Z0-9][A-Z0-9_-]*)+):?(d+)?[\/A-Z0-9_\.-]*$/i", "mobile"=>"/^([A-Z0-9][A-Z0-9_-]*(?:.[A-Z0-9][A-Z0-9_-]*)+):?(d+)?$/i",
            "address"=>"//", "phone"=>"//", "alias"=>"//");
        foreach($items as $k=>$v){
            if(isset($vads[$k])){
                if(!preg_match($vads[$k], trim($v))){
                    $this->setError($k." failed the validity test");
                    return false;
                }
            }
        }
        reset($items);
        if(!empty($items["promcode"]) && $items["promcode"]=="free_trial:1day")
        $basexml="<?xml version='1.0'?>
<request>
  <subscription>
    <billing_cycle>FT</billing_cycle>
    <service_level>1</service_level>
    <promotion_code>free_trial:armo</promotion_code>
    <currency>USD</currency>
    <contract_type>FT</contract_type>
    <spare_1/>
    <spare_2/>
    <sub_reseller_id/>
    <reseller_reference/>
    <mapping>
      <source_domain/>
      <mobile_domain/>
      <properties>
        <address/>
        <phoneText/>
      </properties>
      <aliases/>
    </mapping>
  </subscription>
</request>";
        else $basexml="<?xml version='1.0'?>
<request>
  <subscription>
    <end_date/>
    <billing_cycle>FT</billing_cycle>
    <service_level>1</service_level>
    <promotion_code>free_trial:armo</promotion_code>
    <currency>USD</currency>
    <contract_type>FT</contract_type>
    <spare_1/>
    <spare_2/>
    <sub_reseller_id/>
    <reseller_reference/>
    <mapping>
      <source_domain/>
      <mobile_domain/>
      <properties>
        <address/>
        <phoneText/>
      </properties>
      <aliases/>
    </mapping>
  </subscription>
</request>";
        
        $sxml=new SimpleXMLElement($basexml);
     
        foreach($items as $k=>$v){
            if($k=="spare_1")$sxml->subscription->spare_1=trim($v);
            elseif($k=="spare_2")$sxml->subscription->spare_2=trim($v);
            elseif($k=="sub_reseller_id")$sxml->subscription->sub_reseller_id=trim($v);
            elseif($k=="reseller_reference")$sxml->subscription->reseller_reference=trim($v);
            elseif($k=="source")$sxml->subscription->mapping->source_domain=trim($v);
            elseif($k=="mobile")$sxml->subscription->mapping->mobile_domain=trim($v);
            elseif($k=="address")$sxml->subscription->mapping->properties->address=trim($v);
            elseif($k=="phone")$sxml->subscription->mapping->properties->phoneText=trim($v);
            elseif($k=="alias")$sxml->subscription->mapping->aliases->alias=trim($v);
            elseif($k=="promcode")$sxml->subscription->promotion_code=trim($v);
            elseif($k=="wizard")$sxml->subscription->mapping->properties->wizardStatus=1;
        }
        $this->request=$sxml->asXML();
        return true;
    }
    function renewSubscription($reference, $items=array()){
        $this->setActionRenewRequest();
        
        if(!preg_match("/^[0-9a-fA-F]{16}$/", $reference)){
           $this->setError("Invalid reference - ".$reference);
            return false;
        }
        $this->subscription=$reference;
        if(!is_array($items)){
            $this->setError("invalid payload - not an array");
            return false;
        }
        $itemDefaults=array("end_date"=>"+1 months", "contract_type"=>"AR", "service_level"=>1, "billing_cycle"=>"MO", "currency"=>"USD");
         reset($items);
        $basexml="<?xml version='1.0'?>
<request>
  <subscription>
    <end_date/>
    <contract_type/>
    <service_level/>
    <billing_cycle/>
    <currency/>
    <promotion_code/>
    <spare_1/>
    <spare_2/>
   </subscription>
</request>";
        $sxml=new SimpleXMLElement($basexml);
         
        foreach($itemDefaults as $k=>$v){
            if(isset($items[$k]))$sxml->subscription->{$k}=trim($items[$k]);
            else $sxml->subscription->{$k}=trim($v);
        }
        $this->request=$sxml->asXML();
        return true;
    }
    function changeContract($contract){
        $this->setActionChangeContract();
        
        if($contract!="NO" && $contract!="AR"){
           $this->setError("Invalid contract type - ".$contract." - should be 'AR' or 'NO'");
            return false;
        }
        return $this->makeValueRequest($contract);
    }
    function makeValueRequest($value){
          $basexml="<?xml version='1.0'?>
<request>
  <value>$value</value>
</request>";
        $sxml=new SimpleXMLElement($basexml);
        $this->request=$sxml->asXML();
        return true;
    }
    function buildPropRequest($data){
        $xml=new SimpleXMLElement("<?xml version='1.0'?><request><properties/></request>");
        foreach($data as $k=>$v){
            $xml->properties->$k=$v;
        }
        $this->request=$xml->asXML();
    }
    function updateApps($data){
        $xml=new SimpleXMLElement("<?xml version='1.0'?><request><apps/></request>");
        $i=0;
        foreach($data as $k=>$v){
            if(isset($this->apps[$k])){
                $xml->apps->app[$i]->id=$this->apps[$k]["id"];
                $xml->apps->app[$i]->label=$k;
                if(isset($v["pos"]))$xml->apps->app[$i]->position=$v["pos"];
                else $xml->apps->app[$i]->position=$this->apps[$k]["id"];
                $xml->apps->app[$i]->share=1;
                if(isset($this->apps[$k]["aother"])){
                    foreach($this->apps[$k]["aother"] as $k2=>$v2){
                        if(isset($v[$k2]))$xml->apps->app[$i]->{$k2}=$v[$k2];
                        else $xml->apps->app[$i]->{$k2}=$v2;
                    }
                }
               // $xml->apps->app[$i]->icon_id=$apps[$k]["icon"];
               if(isset($v["value"])) $xml->apps->app[$i]->config[0]->{$this->apps[$k]["vname"]}=$v["value"];
               if(isset($this->apps[$k]["vother"])){
                   foreach($this->apps[$k]["vother"] as $k2=>$v2)$xml->apps->app[$i]->config[0]->$k2=$v2;
               }
                $i++;
                
            }
            
        }
        $this->request=$xml->asXML();
    }
    function updateBatch($data, $prop){
        $xml=new SimpleXMLElement("<?xml version='1.0'?><request><properties/><apps/></request>");
        foreach($prop as $k=>$v){
            $xml->properties->$k=$v;
        }

        $i=0;
  //           "Twitter"=>array("id"=>26, "vname"=>"social_media_link_login", "icon"=>1026),
  
        foreach($data as $k=>$v){
            if(isset($this->apps[$k])){
                $xml->apps->app[$i]->id=$this->apps[$k]["id"];
                $xml->apps->app[$i]->label=$k;
                if(isset($v["pos"]))$xml->apps->app[$i]->position=$v["pos"];
                else $xml->apps->app[$i]->position=$this->apps[$k]["id"];
                $xml->apps->app[$i]->share=1;
                if(isset($this->apps[$k]["aother"])){
                    foreach($this->apps[$k]["aother"] as $k2=>$v2){
                        if(isset($v[$k2]))$xml->apps->app[$i]->{$k2}=$v[$k2];
                        else $xml->apps->app[$i]->{$k2}=$v2;
                    }
                }
               // $xml->apps->app[$i]->icon_id=$apps[$k]["icon"];
               if(isset($v["value"])) $xml->apps->app[$i]->config[0]->{$this->apps[$k]["vname"]}=$v["value"];
               if(isset($this->apps[$k]["vother"])){
                   foreach($this->apps[$k]["vother"] as $k2=>$v2)$xml->apps->app[$i]->config[0]->$k2=$v2;
               }
                $i++;
                
            }
            
        }
        $this->request=$xml->asXML();
    }
      
    function setError($error){
        $this->error=$error;
        return true;
    }
    function getError(){
        return $this->error;
    }
    function logItems($item){
        $ins="\n".date("r")."\n";
        $filename=GM_LOG_LOCATION."/gmclass_".  date("Ymd").".log";
        file_put_contents($filename, $ins.$item, FILE_APPEND);
    }
    
    function addApp($appname, $options=array()){
        static $or=0;
        if(!$this->appreq)$this->appreq=new SimpleXMLElement("<?xml version='1.0'?><request><apps/></request>");
        
        if($appname=="about-link"  && $this->basicAppReq($or, 32, "About", ($or+1), $options)){
            $this->appreq->apps->app[$or]->config[0]->link_url=$options["value"];
            $this->appreq->apps->app[$or]->config[0]->is_link=1;
            $this->appreq->apps->app[$or]->config[0]->page_content="";
        }
        elseif($appname=="about-text"  && $this->basicAppReq($or, 32, "About", ($or+1), $options)){
            $this->appreq->apps->app[$or]->config[0]->link_url="";
            $this->appreq->apps->app[$or]->config[0]->is_link=0;
            $this->appreq->apps->app[$or]->config[0]->page_content=$options["value"];
        }
        elseif($appname=="callus"  && $this->basicAppReq($or, 1, "Call Us", ($or+1), $options)){
            $this->appreq->apps->app[$or]->config[0]->callus_phone=$options["value"];
            $this->appreq->apps->app[$or]->config[0]->is_default_callus=1;
        }
        elseif($appname=="twitter"  && $this->basicAppReq($or, 26, "Twitter", ($or+1), $options)){
           $this->appreq->apps->app[$or]->config[0]->social_media_link_login=$options["value"];
        }
        elseif($appname=="tellafriend"  && $this->basicAppReq($or, 5, "Tell a Friend", ($or+1), $options)){
            $this->appreq->apps->app[$or]->config[0]->sms_body_text=$options["value"];
        }
        elseif($appname=="leaveamessage"  && $this->basicAppReq($or, 7, "Leave a Message", ($or+1), $options)){
            $this->appreq->apps->app[$or]->config[0]->email=$options["value"];
            if(isset($options["description"]))$ins=$options["description"];
            else $ins="";
            $this->appreq->apps->app[$or]->config[0]->leave_message_desc=$ins;
        }
        else return;
        $or++;
        return true;
    }
    
    function basicAppReq($or, $id, $label, $pos, $options=array()){
        if(!isset($this->appreq->apps))return false;
        if(isset($options["ignoreapps"][$id]))return false;
        $this->ignoredApps[$id]=1;
        foreach($options as $k=>$v){
            if($k=="label")$label=$v;
            elseif($k=="pos")$pos=$v;
        }
        $this->appreq->apps->app[$or]->id=$id;
        $this->appreq->apps->app[$or]->label=$label;
        $this->appreq->apps->app[$or]->position=$pos;
        $this->appreq->apps->app[$or]->share=1;
        return true;
    }
    
    function appReqAsXml(){
        if(isset($this->appreq)){
            $this->request=$this->appreq->asXML();
        }
    }
 


}

?>
