<?php

// MsSQL Settings




function sql_merror($query){
	print "<br />Error Message: <i>".mssql_get_last_message()."</i> In Statement: $query";
	die();
}


class DBM{

	
	var $result;
	var $qr;
        var $dbmhost = MSDB_HOST;
        var $dbmname = MSDB_NAME;
        var $dbmpass = MSDB_PASS;
	var $dbmuser = MSDB_USER;
        var $dbconn;


	
	function DBM($query=""){
                $this->dbconn = mssql_connect($this->dbmhost, $this->dbmuser, $this->dbmpass);
                mssql_select_db($this->dbmname);
		if(!$query)return true;
		$this->result=mssql_query($query);
		$this->qr=$query;
		if(!$this->result)$this->sql_error($query);
		return true;
	}
	
	function nq($query, $ret_error=0){
		$this->result=mssql_query($query);
		$this->qr=$query;
		if(!$this->result){
			if($ret_error)return false;
			else $this->sql_error($query);
		}
		return true;
	}
	
	function sql_error($query){
		print "<br />Error Message: <i>".mssql_get_last_message()."</i> In Statement: $query";
		die();
	}

	function row($type = false){
		if(!$type)$ret=mssql_fetch_array($this->result);
		elseif($type=="MSSQL_NUM")$ret = mssql_fetch_row($this->result);
		elseif($type=="MSSQL_ASSOC")$ret = mssql_fetch_assoc($this->result);
		else $ret=mssql_fetch_array($this->result);
		return $ret;
	}
	
	function cr(){
		$count = mssql_num_rows($this->result);
		return $count;
	}
	
	function lid(){
                $result=$this->sr("SELECT SCOPE_IDENTITY() AS ins_id");
		//$result=mssql_insert_id();
		return $result;
	}
	function solo_res(){
		$row=mssql_fetch_row($this->result);
		return $row[0];
	}
	function sr($query){
		$this->nq($query);
		return $this->solo_res();
	}
	function numfields(){
		return mssql_num_fields($this->result);
	}
	function nar(){
		return mssql_rows_affected();
	}
}
?>
