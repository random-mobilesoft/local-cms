<?php

include_once("library/class.phpmailer.php");
$e=new PHPMailer();
$e->AddAddress("rohan@mytinyad.com");
$e->Subject="Test email";
$e->Body="Test body";
$e->Send();
?>

