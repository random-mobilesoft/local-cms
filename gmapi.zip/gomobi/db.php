<?php

// MySQL Settings

/*
$dbhost = "localhost";
$dbname = "mta";
if(empty($dbuser)){
	$dbpass = "MAX1m1s3r";
	$dbuser = "root";
}
*/
/*
$dbconn = mysql_connect($dbhost, $dbuser, $dbpass);
if (! $dbconn) {
    sql_error("connect");
}

// select the database to be used

if (! mysql_select_db($dbname)) {
    sql_error("select_db $dbname");
}

*/


//$url="http://".$_SERVER['HTTP_HOST'];
//define("BT_BASE", $url);

// connect to the database


function sql_error($query){
	print "<br />Error Message: ".mysql_error()."<br />In Statement: $query";
	die();
}


class DBQ{

	
	var $result;
	var $qr;
        var $dbhost = DB_HOST;
        var $dbname = DB_NAME;
        //var $dbpass = ;
	var $dbpass = DB_PASSWORD;
	var $dbuser = DB_USER;
        var $dbconn;


	
	function DBQ($query=""){
                if(!$this->dbconn = mysql_connect($this->dbhost, $this->dbuser, $this->dbpass, true))$this->sql_error("Failed to connect to db server");
                if(!mysql_select_db($this->dbname))$this->sql_error("Failed to connecto database ".$this->dbname);
		if(!$query)return true;
		$this->result=mysql_query($query);
		$this->qr=$query;
		if(!$this->result)$this->sql_error($query);
		return true;
	}
	
	function nq($query, $ret_error=0){
		$this->result=mysql_query($query);
		$this->qr=$query;
		if(!$this->result){
			if($ret_error)return false;
			else $this->sql_error($query);
		}
		return true;
	}
	
	function sql_error($query){
		print "<br />Error Message: ".mysql_error()."<br />In Statement: $query";
		die();
	}

	function row($type = false){
		if(!$type)$ret=mysql_fetch_array($this->result);
		elseif($type=="MYSQL_NUM")$ret = mysql_fetch_row($this->result);
		elseif($type=="MYSQL_ASSOC")$ret = mysql_fetch_assoc($this->result);
		else $ret=mysql_fetch_array($this->result);
		return $ret;
	}
	
	function cr(){
		$count = mysql_num_rows($this->result);
		return $count;
	}
	
	function lid(){
		$result=mysql_insert_id();
		return $result;
	}
	function solo_res(){
		$row=mysql_fetch_row($this->result);
		return $row[0];
	}
	function sr($query){
		$this->nq($query);
		return $this->solo_res();
	}
	function numfields(){
		return mysql_num_fields($this->result);
	}
	function nar(){
		return mysql_affected_rows();
	}
}
?>
