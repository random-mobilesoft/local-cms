<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
$letterfile="/sites/localmobi/web/gomobi/reminder.letter.template";
if(!is_file($letterfile))exit("no letter file");
include_once("config.php");
include_once("db.php");
//include_once("functions.php");
// include_once("common/sessions.php"  );
$d = new DBQ();
//include_once("common/auth.php");

$d->nq("SELECT t1_int, t1_email, t1_url, t1_mobile_url FROM t1day WHERE t1_cts between date_sub(now(), interval 1 day) and date_sub(now(), interval 20 hour) and t1_reminder=0 and t1_status=0");
//$d->nq("SELECT 5 t1_int, 'rohan@local.mobi' t1_email, 'www.nversee.com' t1_url, 'bigfootycom24.local.mobi' t1_mobile_url");
if(!$d->cr())exit();
include_once("library/class.phpmailer.php");
$letter=  file_get_contents($letterfile);
$g=new DBQ();
while($row=$d->row()){
    $e=new PHPMailer();
    $e->AddAddress($row["t1_email"]);
    $e->IsHTML(true);
    $e->From="info@local.mobi";
    $e->FromName="local.mobi";
    $e->Subject="Claim your 24hr mobile website, only 3 hours to go... ";
    $body=  str_replace("[murl]", $row["t1_mobile_url"], $letter);
    $e->Body=$body;
    
    $e->Send();

    $g->nq("update t1day set t1_reminder=1 where t1_int=".$row["t1_int"]);
}
?>
