<?php
include_once("config.php");
include_once("db.php");

function get_param($name, $type="")
{
    
	if (isset($_REQUEST[$name])){
		if($type=="d"){
			if(is_numeric($_REQUEST[$name]))return $_REQUEST[$name];
		}
                elseif($type=="s") return mysql_real_escape_string ($_REQUEST[$name]);
		else return addslashes($_REQUEST[$name]);
    }
	return "";
}

function get_jm_gomobi_link(){
global $wpdb;
$private_keyfile = '/etc/ssl/certs/gomobi.private.key';
// Load private key
$privkey = file_get_contents($private_keyfile);
$pkeyid = openssl_pkey_get_private($privkey);
// Reseller id, .mobi domain, time
//$reseller_id = 65590;                 // MyTinyAd Production Reseller ID
if(!empty($_REQUEST["lm_sandbox"]))$sandbox=1;
else $sandbox=0;

if(isset($_REQUEST["lm_url"]))$mobile_domain_name=$_REQUEST["lm_url"];
else $mobile_domain_name="missing";
if(substr($mobile_domain_name,0,8)=="https://")$mobile_domain_name=substr($mobile_domain_name,8);
elseif(substr($mobile_domain_name,0,7)=="http://")$mobile_domain_name=substr($mobile_domain_name,7);

if(substr($mobile_domain_name, -14)==".sb.local.mobi")$sandbox=1;

if($sandbox)$reseller_id=65573;
else $reseller_id  = 65590;

$d=new DBQ();
$d->nq("select t1_int from t1workday where t1_mobile_url='".mysql_real_escape_string($mobile_domain_name)."' and t1_status=0");
$val="";
if($d->cr()){
    $row=$d->row();
    $val=$row["t1_int"];
}
if(!$val){
    print "expired";
    exit();
}


$time = time();
// A message to sign
$msg = implode('/', array($reseller_id, $mobile_domain_name, $time));
// Sign the message
openssl_sign($msg, $signature, $pkeyid);
openssl_pkey_free($pkeyid);
// Final URL
//$cp_entry_point = 'https://cp.instantmobilizer.com';
//$cp_entry_point = 'https://cp-sandbox.instantmobilizer.com';

if($sandbox)$cp_entry_point = "https://cp-sandbox.instantmobilizer.com";
else $cp_entry_point = "https://cp.instantmobilizer.com";
$lang = 'en';
$url = $cp_entry_point."/".$msg."/".urlencode(base64_encode($signature))."/".$lang;
print $url;
}
get_jm_gomobi_link();
?>
