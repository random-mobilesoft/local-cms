<?php
include_once("config.php");
include_once("db.php");

function get_param($name, $type="")
{
    
	if (isset($_REQUEST[$name])){
		if($type=="d"){
			if(is_numeric($_REQUEST[$name]))return $_REQUEST[$name];
		}
                elseif($type=="s") return mysql_real_escape_string ($_REQUEST[$name]);
		else return addslashes($_REQUEST[$name]);
    }
	return "";
}

$url=get_param("mobiledomain");
$email=get_param("email");
$fname=get_param("firstname");
$lname=get_param("lastname");
$password=  get_param("password");
$username=  get_param("username");
$debug=get_param("debug");
$sandbox=get_param("sandbox");

if(substr($url,0,8)=="https://")$url=substr($url,8);
elseif(substr($url,0,7)=="http://")$url=substr($url,7);


$req=array("mobiledomain"=>$url,
        "firstname"=>$fname,
        "lastname"=>$lname,
        "email"=>$email,
        "username"=>$username,
        "password"=>$password,
        "secret"=>MTA_RS_SECRET,
        "api"=>MTA_RS_API,
        "reseller"=>"localmobi",
        "type"=>"24site");

if($debug)$req["debug"]="yes";
if($sandbox)$req["sandbox"]="true";

$d=new DBQ();
$refid="";
$rid="";
$d->nq("select t1_int, t1_subscription from t1day where t1_mobile_url='$url' and t1_cts>date_sub(now(), interval 1 day) and t1_status=0 limit 1");
while($row=$d->row()){
    $rid=$row["t1_int"];
    $refid=$row["t1_subscription"];
    break;
}
if(!$refid){    
    header("Location: ".MTA_HOME."create-mobile-site/failed/?errormsg=".  urlencode($url." is not valid"));
    exit();
}
$req["subscription"]=$refid;


$postrequest="";
foreach ($req as $key=>$val)$postrequest.=$key.'='.urlencode($val).'&';

$ch = curl_init(MTA_API_SERVER."?".$postrequest);
curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt ($ch, CURLOPT_TIMEOUT, 90);
//curl_setopt ($ch, CURLOPT_POSTFIELDS, $postrequest);
//curl_setopt ($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
$response = curl_exec ($ch);
$last_url = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL); 
$errno = curl_errno ($ch);
$err_str = curl_error ($ch);
curl_close ($ch);

if(strpos($response, "success")!==false){
    $d->nq("update t1day set t1_status=1 where t1_int=$rid");
     header("Location: ".MTA_HOME."control-panel/");
}
else{
    header("Location: ".MTA_HOME."create-mobile-site/failed/?errormsg=".  urlencode($response));
}
?>
