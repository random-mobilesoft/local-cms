<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
include_once("config.php");
include_once("db.php");
include_once("functions.php");
include_once("library/class.phpmailer.php");
// include_once("common/sessions.php"  );
$d = new DBQ("SET SESSION time_zone='Australia/Melbourne'");
//include_once("common/auth.php");

$d->nq("SELECT t1_int, t1_email, t1_url, t1_mobile_url, case when t1_status=1 then 'Yes' else 'No' end status, case when t1_reminder=1 then 'Yes' else 'No' end reminder, 
    t1_cts FROM t1day WHERE t1_cts between date_sub(now(), interval 2 day) and now()");

$content="<html><head></head><body>";

$content.="\n<h1>Activity in the last 48 hours</h1>";

if(!$d->cr())$content.="\n<p><b>No activity</b></p>";
else{
    ob_start();
    start_table();
    start_row();
    print "\n<th>Web Site</th><th>Mobile Site</th><th>Email</th><th>Progressed</th><th>reminder Sent</th><th>Date Created</th>";
    end_row();
    while($row=$d->row()){
        start_row();
        print_data("", $row["t1_url"]);
        print_data("", $row["t1_mobile_url"]);
        print_data("", $row["t1_email"]);
        print_data("", $row["status"]);
        print_data("", $row["reminder"]);
        print_data("", $row["t1_cts"]);
        end_row();
        
    }
    end_table();
    $content.=ob_get_clean();
}





$e=new PHPMailer();
$e->AddAddress("rohan@local.mobi");
$e->AddAddress("info@local.mobi");
$e->IsHTML(true);
$e->From="info@local.mobi";
$e->FromName="local.mobi";
$e->Subject="Activity for last 48 hours of 24 hour site subscriptions";
$e->Body=$content;

$e->Send();


?>
